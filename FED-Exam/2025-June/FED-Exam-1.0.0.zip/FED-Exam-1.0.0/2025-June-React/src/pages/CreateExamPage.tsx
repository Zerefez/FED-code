import { CreateExamForm } from '@/components/exam/create-exam-form';
import { useNavigate } from 'react-router-dom';

export function CreateExamPage() {
  const navigate = useNavigate();


  const handleExamCreated = async () => {
    // The exam is already created by the form component
    navigate('/exams');
  };

  const handleCancel = () => {
    // Navigate back to previous page or exams list
    navigate(-1);
  };

  return (
    <div>
      <CreateExamForm 
        onExamCreated={handleExamCreated}
        onCancel={handleCancel}
      />
    </div>
  );
} 