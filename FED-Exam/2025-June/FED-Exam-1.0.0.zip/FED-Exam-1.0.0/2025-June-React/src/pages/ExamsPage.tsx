import { ExamList } from '@/components/exam/exam-list';
import { useExams } from '@/hooks';
import type { Exam } from '@/types/exam';
import { useNavigate } from 'react-router-dom';

export function ExamsPage() {
  const navigate = useNavigate();
  const { items: exams, loading, error } = useExams();

  const handleCreateExam = () => {
    navigate('/create-exam');
  };

  const handleSelectExam = (exam: Exam) => {
    navigate(`/start-exam/${exam.id}`);
  };

  if (error) {
    return (
      <div className="text-center p-8">
        <p className="text-destructive">Fejl: {error}</p>
      </div>
    );
  }

  return (
    <div>
      <ExamList 
        exams={exams}
        loading={loading}
        onCreateExam={handleCreateExam}
        onSelectExam={handleSelectExam}
      />
    </div>
  );
} 