export { CreateExamPage } from './CreateExamPage';
export { ExamsPage } from './ExamsPage';
export { HistoryPage } from './HistoryPage';
export { HomePage } from './HomePage';
export { StartExamPage } from './StartExamPage';

