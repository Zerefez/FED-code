import { ExamCompleted } from '@/components/exam/exam-completed';
import { ExamList } from '@/components/exam/exam-list';
import { ExamOverview } from '@/components/exam/exam-overview';
import { ExamSession } from '@/components/exam/exam-session';
import { StudentForm } from '@/components/exam/student-form';
import { StudentList } from '@/components/exam/student-list';
import { Button } from '@/components/ui/button';
import { ExamProvider, ExamSessionProvider, useExamContext, useExamSessionContext } from '@/contexts';
import { useExams } from '@/hooks';
import type { Exam } from '@/types/exam';
import { useNavigate, useParams } from 'react-router-dom';

// Inner component that uses contexts
function StartExamContent() {
  const navigate = useNavigate();
  const { exam, isLoading } = useExamContext();
  const { pageState, setPageState } = useExamSessionContext();

  // Navigation handlers
  const handleNavigateToHistory = () => navigate('/history');
  const handleNavigateToExams = () => navigate('/exams');
  const handleBackToOverview = () => setPageState('overview');

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <p className="text-muted-foreground">Indlæser eksamen...</p>
      </div>
    );
  }

  if (!exam) {
    return (
      <div className="space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">Start Eksamen</h1>
          <p className="text-muted-foreground mb-6">
            Vælg en eksamen for at starte eller administrere studerende
          </p>
          <Button onClick={handleNavigateToExams}>
            Vælg Eksamen
          </Button>
        </div>
      </div>
    );
  }

  const renderPageHeader = () => (
    <div className="flex justify-between items-center">
      <div>
        <h1 className="text-3xl font-bold">{exam.courseName}</h1>
        <p className="text-muted-foreground">{exam.examtermin}</p>
      </div>
      <Button onClick={handleNavigateToExams} variant="outline">
        Tilbage til Eksamener
      </Button>
    </div>
  );

  // Show student form
  if (pageState === 'adding-students') {
    return (
      <div className="space-y-6">
        {renderPageHeader()}
        <StudentForm />
      </div>
    );
  }

  // Show exam session
  if (pageState === 'exam-running') {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">{exam.courseName}</h1>
            <p className="text-muted-foreground">{exam.examtermin}</p>
          </div>
          <Button onClick={handleBackToOverview} variant="outline">
            Tilbage til oversigt
          </Button>
        </div>
        
        <ExamSession />
      </div>
    );
  }

  // Show exam completed
  if (pageState === 'exam-completed') {
    return (
      <ExamCompleted
        onNavigateToHistory={handleNavigateToHistory}
        onNavigateToExams={handleNavigateToExams}
      />
    );
  }

  // Show main overview (default)
  return (
    <div className="space-y-6">
      {renderPageHeader()}
      <ExamOverview />
      <StudentList />
    </div>
  );
}

// Component to show exam selection when no examId is provided
function ExamSelection() {
  const navigate = useNavigate();
  const { items: exams, loading, error } = useExams();

  const handleSelectExam = (exam: Exam) => {
    navigate(`/start-exam/${exam.id}`);
  };

  const handleCreateExam = () => {
    navigate('/create-exam');
  };

  if (error) {
    return (
      <div className="text-center p-8">
        <p className="text-destructive">Fejl: {error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-4">Start Eksamen</h1>
        <p className="text-muted-foreground mb-6">
          Vælg en eksamen for at starte eller administrere studerende
        </p>
      </div>
      
      <ExamList 
        exams={exams}
        loading={loading}
        onCreateExam={handleCreateExam}
        onSelectExam={handleSelectExam}
      />
    </div>
  );
}

// Main component that provides contexts
export function StartExamPage() {
  const { examId } = useParams<{ examId: string }>();

  // If no examId is provided, show exam selection
  if (!examId) {
    return <ExamSelection />;
  }

  return (
    <ExamProvider examId={examId}>
      <ExamSessionProvider>
        <StartExamContent />
      </ExamSessionProvider>
    </ExamProvider>
  );
} 