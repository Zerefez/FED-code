import { AppRouter } from '@/components/router'
import { ThemeProvider } from '@/components/theme-provider'
import React from 'react'

const App: React.FC = () => {
  return (
    <ThemeProvider defaultTheme="system" storageKey="vite-ui-theme">
      <AppRouter />
    </ThemeProvider>
  )
}

export default App 