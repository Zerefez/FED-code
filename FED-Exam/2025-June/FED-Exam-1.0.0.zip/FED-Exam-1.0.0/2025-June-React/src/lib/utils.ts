import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Date formatting utilities
export function formatDate(dateString: string, style: 'long' | 'short' = 'long'): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('da-DK', {
    year: 'numeric',
    month: style === 'long' ? 'long' : 'short',
    day: 'numeric'
  });
}

// Student filtering utilities
export function filterCompletedStudents(students: any[]): any[] {
  return students.filter(student => student.grade);
}

export function filterUncompletedStudents(students: any[]): any[] {
  return students.filter(student => !student.grade);
}

// Validation utilities
export function isRequired(value: string | undefined | null): boolean {
  return !value || !value.trim();
}

export function findDuplicates<T>(array: T[]): T[] {
  return array.filter((item, index) => array.indexOf(item) !== index);
}

// Grade calculation utilities
export function calculateAverageGrade(students: any[]): number | null {
  const completedStudents = filterCompletedStudents(students);
  if (completedStudents.length === 0) return null;
  
  const gradeSum = completedStudents.reduce((sum, student) => {
    const grade = parseInt(student.grade || '0');
    return sum + (isNaN(grade) ? 0 : grade);
  }, 0);
  
  return gradeSum / completedStudents.length;
}

// Exam completion lock utilities
const COMPLETION_LOCK_KEY = 'exam-completion-lock';

export const completionLock = {
  /**
   * Check if exam completion is locked
   */
  isLocked(): boolean {
    try {
      return localStorage.getItem(COMPLETION_LOCK_KEY) === 'true';
    } catch {
      return false;
    }
  },

  /**
   * Set completion lock
   */
  lock(): void {
    try {
      localStorage.setItem(COMPLETION_LOCK_KEY, 'true');
    } catch (error) {
      console.warn('Failed to set completion lock:', error);
    }
  },

  /**
   * Clear completion lock
   */
  unlock(): void {
    try {
      localStorage.removeItem(COMPLETION_LOCK_KEY);
    } catch (error) {
      console.warn('Failed to clear completion lock:', error);
    }
  }
}; 