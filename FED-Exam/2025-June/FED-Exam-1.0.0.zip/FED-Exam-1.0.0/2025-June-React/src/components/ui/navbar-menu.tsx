import { cn } from "@/lib/utils";
import React from "react";

interface NavbarProps {
  className?: string;
  children: React.ReactNode;
}

export const Navbar = ({ className, children }: NavbarProps) => {
  return (
    <nav
      className={cn(
        "flex items-center justify-between w-full px-6 py-4 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border",
        className
      )}
    >
      {children}
    </nav>
  );
};

interface NavbarBrandProps {
  children: React.ReactNode;
  className?: string;
}

export const NavbarBrand = ({ children, className }: NavbarBrandProps) => {
  return (
    <div className={cn("flex items-center space-x-2", className)}>
      {children}
    </div>
  );
};

interface NavbarMenuProps {
  children: React.ReactNode;
  className?: string;
}

export const NavbarMenu = ({ children, className }: NavbarMenuProps) => {
  return (
    <div className={cn("flex items-center space-x-6", className)}>
      {children}
    </div>
  );
};

interface NavbarItemProps {
  children: React.ReactNode;
  onClick?: () => void;
  active?: boolean;
  className?: string;
}

export const NavbarItem = ({ children, onClick, active = false, className }: NavbarItemProps) => {
  return (
    <button
      onClick={onClick}
      className={cn(
        "text-sm font-medium transition-colors hover:text-primary",
        active 
          ? "text-primary" 
          : "text-muted-foreground",
        className
      )}
    >
      {children}
    </button>
  );
};

interface NavbarActionsProps {
  children: React.ReactNode;
  className?: string;
}

export const NavbarActions = ({ children, className }: NavbarActionsProps) => {
  return (
    <div className={cn("flex items-center space-x-4", className)}>
      {children}
    </div>
  );
};
