import { useEffect, useRef, useState } from 'react';

interface UseExamTimerReturn {
  timeRemaining: number;
  actualExamTime: number;
  isRunning: boolean;
  startTimer: () => void;
  stopTimer: () => void;
  resetTimer: (durationMinutes: number) => void;
}

export function useExamTimer(initialDurationMinutes: number): UseExamTimerReturn {
  const [timeRemaining, setTimeRemaining] = useState(initialDurationMinutes * 60);
  const [actualExamTime, setActualExamTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const timerIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Audio notification - no need for useCallback here
  const playTimerSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = 800;
      oscillator.type = 'sine';
      gainNode.gain.value = 0.3;
      
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 0.5);
    } catch (error) {
      console.warn('Could not play audio:', error);
    }
  };

  const startTimer = () => {
    if (timerIntervalRef.current) return; // Already running
    
    setIsRunning(true);
    setActualExamTime(0);
    
    const interval = setInterval(() => {
      setTimeRemaining(prev => {
        const newTime = prev - 1;
        setActualExamTime(prevActual => prevActual + 1);
        
        if (newTime <= 0) {
          playTimerSound();
          return 0;
        }
        
        // Play warning sound at 1 minute remaining
        if (newTime === 60) {
          playTimerSound();
        }
        
        return newTime;
      });
    }, 1000);
    
    timerIntervalRef.current = interval;
  };

  const stopTimer = () => {
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    setIsRunning(false);
    playTimerSound();
  };

  const resetTimer = (durationMinutes: number) => {
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    setTimeRemaining(durationMinutes * 60);
    setActualExamTime(0);
    setIsRunning(false);
  };

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    };
  }, []);

  return {
    timeRemaining,
    actualExamTime,
    isRunning,
    startTimer,
    stopTimer,
    resetTimer,
  };
} 