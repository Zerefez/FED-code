import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Student } from '@/types/exam';
import { User } from 'lucide-react';

interface StudentInfoCardProps {
  student: Student;
  currentIndex: number;
  totalStudents: number;
}

export function StudentInfoCard({ student, currentIndex, totalStudents }: StudentInfoCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <User className="h-5 w-5" />
          Nuværende studerende ({currentIndex + 1} af {totalStudents})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Navn</p>
            <p className="font-medium">{student.firstName} {student.lastName}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Studienummer</p>
            <p className="font-medium">{student.studenNo}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
} 