import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useExamContext, useExamSessionContext } from '@/contexts';
import { useForm, useStudents } from '@/hooks';
import type { CreateStudentData } from '@/types/exam';
import { Plus, X } from 'lucide-react';

interface StudentFormState {
  students: CreateStudentData[];
}

const initialFormData: StudentFormState = {
  students: [{ studenNo: '', firstName: '', lastName: '' }]
};

export function StudentForm() {
  const { exam, students: existingStudents, handleStudentAdded } = useExamContext();
  const { handleStudentFormCancel } = useExamSessionContext();
  const { create: createStudent } = useStudents();
  const {
    data: formData,
    errors,
    loading: isLoading,
    set,
    setError,
    clearError,
    handleSubmit,
  } = useForm<StudentFormState>(initialFormData);

  if (!exam) {
    return null; // Should not render if no exam
  }

  const addStudentRow = () => {
    const newStudents = [...formData.students, { studenNo: '', firstName: '', lastName: '' }];
    set('students', newStudents);
  };

  const removeStudentRow = (index: number) => {
    if (formData.students.length > 1) {
      const newStudents = formData.students.filter((_, i) => i !== index);
      set('students', newStudents);
      
      // Clear any errors for removed row
      Object.keys(errors).forEach(key => {
        if (key.startsWith(`${index}_`)) {
          clearError(key as keyof StudentFormState);
        }
      });
    }
  };

  const updateStudent = (index: number, field: keyof CreateStudentData, value: string) => {
    const newStudents = formData.students.map((student, i) => 
      i === index ? { ...student, [field]: value } : student
    );
    set('students', newStudents);
    
    // Clear error for this field
    const errorKey = `${index}_${field}`;
    if (errors[errorKey]) {
      clearError(errorKey as keyof StudentFormState);
    }
  };

  const validateForm = (): boolean => {
    let isValid = true;
    const existingStudentNumbers = existingStudents.map(s => s.studenNo);

    formData.students.forEach((student, index) => {
      if (!student.studenNo.trim()) {
        setError(`${index}_studenNo` as keyof StudentFormState, 'Studienummer er påkrævet');
        isValid = false;
      } else if (existingStudentNumbers.includes(student.studenNo.trim())) {
        setError(`${index}_studenNo` as keyof StudentFormState, 'Dette studienummer findes allerede');
        isValid = false;
      }

      if (!student.firstName.trim()) {
        setError(`${index}_firstName` as keyof StudentFormState, 'Fornavn er påkrævet');
        isValid = false;
      }

      if (!student.lastName.trim()) {
        setError(`${index}_lastName` as keyof StudentFormState, 'Efternavn er påkrævet');
        isValid = false;
      }
    });

    // Check for duplicate student numbers in the form
    const studentNumbers = formData.students.map(s => s.studenNo.trim()).filter(Boolean);
    const duplicates = studentNumbers.filter((num, index) => studentNumbers.indexOf(num) !== index);
    
    duplicates.forEach(duplicate => {
      formData.students.forEach((student, index) => {
        if (student.studenNo.trim() === duplicate) {
          setError(`${index}_studenNo` as keyof StudentFormState, 'Studienummer må ikke være ens');
          isValid = false;
        }
      });
    });

    return isValid;
  };

  const onSubmit = async (data: StudentFormState) => {
    if (!validateForm()) {
      return;
    }

    try {
      // Create students in the order they were entered
      for (let i = 0; i < data.students.length; i++) {
        const student = data.students[i];
        const studentData = {
          exam: exam.id,
          studenNo: student.studenNo.trim(),
          firstName: student.firstName.trim(),
          lastName: student.lastName.trim(),
          // Don't assign question numbers yet - they can be assigned later
        };

        const createdStudent = await createStudent(studentData);
        if (createdStudent) {
          handleStudentAdded(createdStudent);
        }
      }
      // Close the form after successful submission
      handleStudentFormCancel();
    } catch (error) {
      console.error('Fejl ved oprettelse af studerende:', error);
      // You might want to show a user-friendly error message here
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>Tilføj studerende</CardTitle>
        <CardDescription>
          Indtast studienummer og navn på studerende i den rækkefølge de skal eksamineres i
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="space-y-4">
            {formData.students.map((student, index) => (
              <div key={index} className="border rounded-lg p-4 space-y-4">
                <div className="flex justify-between items-center">
                  <h4 className="font-medium">Studerende {index + 1}</h4>
                  {formData.students.length > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removeStudentRow(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor={`studenNo-${index}`}>Studienummer</Label>
                    <Input
                      id={`studenNo-${index}`}
                      type="text"
                      placeholder="f.eks. 123456"
                      value={student.studenNo}
                      onChange={(e) => updateStudent(index, 'studenNo', e.target.value)}
                      aria-invalid={!!errors[`${index}_studenNo`]}
                    />
                    {errors[`${index}_studenNo`] && (
                      <p className="text-sm text-destructive">{errors[`${index}_studenNo`]}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`firstName-${index}`}>Fornavn</Label>
                    <Input
                      id={`firstName-${index}`}
                      type="text"
                      placeholder="f.eks. Alice"
                      value={student.firstName}
                      onChange={(e) => updateStudent(index, 'firstName', e.target.value)}
                      aria-invalid={!!errors[`${index}_firstName`]}
                    />
                    {errors[`${index}_firstName`] && (
                      <p className="text-sm text-destructive">{errors[`${index}_firstName`]}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`lastName-${index}`}>Efternavn</Label>
                    <Input
                      id={`lastName-${index}`}
                      type="text"
                      placeholder="f.eks. Andersen"
                      value={student.lastName}
                      onChange={(e) => updateStudent(index, 'lastName', e.target.value)}
                      aria-invalid={!!errors[`${index}_lastName`]}
                    />
                    {errors[`${index}_lastName`] && (
                      <p className="text-sm text-destructive">{errors[`${index}_lastName`]}</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-between items-center">
            <Button type="button" variant="outline" onClick={addStudentRow} className="gap-2">
              <Plus className="h-4 w-4" />
              Tilføj flere studerende
            </Button>
            
            <div className="flex gap-4">
              <Button type="button" variant="outline" onClick={handleStudentFormCancel}>
                Annuller
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? 'Tilføjer...' : 'Tilføj studerende'}
              </Button>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );
} 