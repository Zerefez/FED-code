import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface QuestionDrawingCardProps {
  numberOfQuestions: number;
  onDrawQuestion: () => void;
}

export function QuestionDrawingCard({ numberOfQuestions, onDrawQuestion }: QuestionDrawingCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Trin 1: Træk spørgsmål</CardTitle>
        <CardDescription>
          Klik for at trække et tilfældigt spørgsmål mellem 1 og {numberOfQuestions}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Button onClick={onDrawQuestion} size="lg" className="w-full">
          Træk spørgsmål
        </Button>
      </CardContent>
    </Card>
  );
} 