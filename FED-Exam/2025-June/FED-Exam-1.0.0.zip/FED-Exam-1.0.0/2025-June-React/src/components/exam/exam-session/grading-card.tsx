import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface GradingCardProps {
  grade: string;
  drawnQuestion: number | null;
  actualExamTime: number;
  notes: string;
  isLastStudent: boolean;
  isSubmitting: boolean;
  onGradeChange: (grade: string) => void;
  onSubmit: () => void;
}

const gradeOptions = ['12', '10', '7', '4', '02', '00', '-3'];

export function GradingCard({
  grade,
  drawnQuestion,
  actualExamTime,
  notes,
  isLastStudent,
  isSubmitting,
  onGradeChange,
  onSubmit
}: GradingCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Trin 4: Indtast karakter</CardTitle>
        <CardDescription>
          Vælg eller indtast den studerendes karakter. Dette vil gemme alle data.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="grade">Karakter</Label>
          <div className="flex gap-2 flex-wrap mt-2">
            {gradeOptions.map((gradeOption) => (
              <Button
                key={gradeOption}
                type="button"
                variant={grade === gradeOption ? "default" : "outline"}
                size="sm"
                onClick={() => onGradeChange(gradeOption)}
              >
                {gradeOption}
              </Button>
            ))}
          </div>
          <div className="mt-2">
            <Input
              id="grade"
              type="text"
              placeholder="Eller indtast karakter"
              value={grade}
              onChange={(e) => onGradeChange(e.target.value)}
            />
          </div>
        </div>

        <div className="bg-blue-50 p-4 rounded-md border border-blue-200">
          <h4 className="font-medium text-blue-900 mb-2">Data der gemmes:</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Spørgsmål nummer: {drawnQuestion}</li>
            <li>• Faktisk eksaminationstid: {Math.ceil(actualExamTime / 60)} minutter</li>
            <li>• Noter: {notes.trim() || 'Ingen noter'}</li>
            <li>• Karakter: {grade || 'Ikke angivet'}</li>
          </ul>
        </div>

        <div className="flex gap-4">
          <Button 
            onClick={onSubmit} 
            disabled={!grade.trim() || isSubmitting}
            className="flex-1"
          >
            {isSubmitting ? 'Gemmer...' : (isLastStudent ? 'Afslut eksamen' : 'Næste studerende')}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
} 