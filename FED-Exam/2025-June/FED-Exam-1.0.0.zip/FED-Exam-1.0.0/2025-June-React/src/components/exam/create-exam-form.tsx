import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useExams, useForm } from '@/hooks';
import { useValidation, validators } from '@/hooks/useValidation';
import type { CreateExamData, Exam } from '@/types/exam';

interface CreateExamFormProps {
  onExamCreated: (exam: Exam) => void;
  onCancel: () => void;
}

const initialFormData: CreateExamData = {
  examtermin: '',
  courseName: '',
  date: '',
  numberOfQuestions: 1,
  examDurationMinutes: 15,
  startTime: '09:00',
};

// Validation rules for the form
const validationRules = [
  { field: 'examtermin' as const, validator: validators.required },
  { field: 'courseName' as const, validator: validators.required },
  { field: 'date' as const, validator: validators.required },
  { field: 'numberOfQuestions' as const, validator: validators.min(1) },
  { field: 'examDurationMinutes' as const, validator: validators.min(1) },
  { field: 'startTime' as const, validator: validators.required },
];

export function CreateExamForm({ onExamCreated, onCancel }: CreateExamFormProps) {
  const { create: createExam } = useExams();
  const { data: formData, loading: isLoading, set, handleSubmit } = useForm<CreateExamData>(initialFormData);
  const { errors, validate, clearError } = useValidation<CreateExamData>();

  const handleInputChange = (field: keyof CreateExamData, value: string | number) => {
    set(field, value);
    clearError(field);
  };

  const onSubmit = async (data: CreateExamData) => {
    if (!validate(data, validationRules)) {
      return;
    }

    try {
      const exam = await createExam(data);
      if (exam) {
        onExamCreated(exam);
      }
    } catch (error) {
      console.error('Fejl ved oprettelse af eksamen:', error);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Opret ny eksamen</CardTitle>
        <CardDescription>
          Indtast oplysninger om den mundtlige eksamen
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="examtermin">Eksamenstermin</Label>
              <Input
                id="examtermin"
                type="text"
                placeholder="f.eks. sommer 25"
                value={formData.examtermin}
                onChange={(e) => handleInputChange('examtermin', e.target.value)}
                aria-invalid={!!errors.examtermin}
              />
              {errors.examtermin && (
                <p className="text-sm text-destructive">{errors.examtermin}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="courseName">Kursusnavn</Label>
              <Input
                id="courseName"
                type="text"
                placeholder="f.eks. Introduktion til Programmering"
                value={formData.courseName}
                onChange={(e) => handleInputChange('courseName', e.target.value)}
                aria-invalid={!!errors.courseName}
              />
              {errors.courseName && (
                <p className="text-sm text-destructive">{errors.courseName}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="date">Dato</Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => handleInputChange('date', e.target.value)}
                aria-invalid={!!errors.date}
              />
              {errors.date && (
                <p className="text-sm text-destructive">{errors.date}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="startTime">Starttidspunkt</Label>
              <Input
                id="startTime"
                type="time"
                value={formData.startTime}
                onChange={(e) => handleInputChange('startTime', e.target.value)}
                aria-invalid={!!errors.startTime}
              />
              {errors.startTime && (
                <p className="text-sm text-destructive">{errors.startTime}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="numberOfQuestions">Antal spørgsmål</Label>
              <Input
                id="numberOfQuestions"
                type="number"
                min="1"
                value={formData.numberOfQuestions}
                onChange={(e) => handleInputChange('numberOfQuestions', parseInt(e.target.value) || 1)}
                aria-invalid={!!errors.numberOfQuestions}
              />
              {errors.numberOfQuestions && (
                <p className="text-sm text-destructive">{errors.numberOfQuestions}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="examDurationMinutes">Eksaminationstid (minutter)</Label>
              <Input
                id="examDurationMinutes"
                type="number"
                min="1"
                value={formData.examDurationMinutes}
                onChange={(e) => handleInputChange('examDurationMinutes', parseInt(e.target.value) || 15)}
                aria-invalid={!!errors.examDurationMinutes}
              />
              {errors.examDurationMinutes && (
                <p className="text-sm text-destructive">{errors.examDurationMinutes}</p>
              )}
            </div>
          </div>

          <div className="flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuller
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? 'Opretter...' : 'Opret eksamen'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
} 