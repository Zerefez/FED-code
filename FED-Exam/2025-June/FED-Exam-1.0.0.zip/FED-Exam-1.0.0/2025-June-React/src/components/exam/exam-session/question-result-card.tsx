import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface QuestionResultCardProps {
  questionNumber: number;
}

export function QuestionResultCard({ questionNumber }: QuestionResultCardProps) {
  return (
    <Card className="border-green-200 bg-green-50">
      <CardHeader>
        <CardTitle className="text-green-800">✓ Trukket spørgsmål</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-center">
          <div className="text-6xl font-bold text-green-600 mb-2">{questionNumber}</div>
          <p className="text-green-700 font-medium">Spørgsmål nummer</p>
        </div>
      </CardContent>
    </Card>
  );
} 