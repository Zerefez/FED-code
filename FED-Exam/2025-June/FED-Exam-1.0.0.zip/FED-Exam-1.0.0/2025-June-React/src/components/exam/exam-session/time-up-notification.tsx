import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Clock, Square } from 'lucide-react';

interface TimeUpNotificationProps {
  onStopExamination: () => void;
}

export function TimeUpNotification({ onStopExamination }: TimeUpNotificationProps) {
  return (
    <Card className="border-red-200 bg-red-50">
      <CardContent className="pt-6">
        <div className="text-center">
          <Clock className="h-12 w-12 mx-auto text-red-500 mb-2" />
          <h3 className="text-lg font-semibold text-red-700">Tiden er udløbet!</h3>
          <p className="text-red-600 mb-4">
            Den tildelte eksaminationstid er brugt. Du kan stadig fortsætte eller stoppe eksaminationen.
          </p>
          <Button onClick={onStopExamination} variant="destructive" className="gap-2">
            <Square className="h-4 w-4" />
            Slut eksamination nu
          </Button>
        </div>
      </CardContent>
    </Card>
  );
} 