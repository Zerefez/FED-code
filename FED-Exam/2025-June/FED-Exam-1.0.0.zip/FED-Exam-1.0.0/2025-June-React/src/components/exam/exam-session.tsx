import { Card, CardContent } from '@/components/ui/card';
import { useExamContext, useExamSessionContext } from '@/contexts';
import { useStudents } from '@/hooks';
import { useEffect, useState } from 'react';
import {
  drawRandomQuestion,
  formatTime,
  getTimerColor,
  GradingCard,
  NotesCard,
  QuestionDrawingCard,
  QuestionResultCard,
  StartExamCard,
  StudentInfoCard,
  TimerControlsCard,
  TimeUpNotification,
  useExamTimer
} from './exam-session/index';

type ExamState = 'waiting' | 'question-drawn' | 'in-progress' | 'finished';

export function ExamSession() {
  const { exam, uncompletedStudents, handleStudentUpdate } = useExamContext();
  const { currentStudentIndex, handleNextStudent, handleExamComplete } = useExamSessionContext();
  const { update: updateStudent } = useStudents();
  const [examState, setExamState] = useState<ExamState>('waiting');
  const [drawnQuestion, setDrawnQuestion] = useState<number | null>(null);
  const [notes, setNotes] = useState('');
  const [grade, setGrade] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!exam) {
    return (
      <Card>
        <CardContent className="text-center py-8">
          <p className="text-muted-foreground">Ingen eksamen fundet</p>
        </CardContent>
      </Card>
    );
  }

  // Use custom timer hook
  const {
    timeRemaining,
    actualExamTime,
    startTimer,
    stopTimer,
    resetTimer
  } = useExamTimer(exam.examDurationMinutes);

  const currentStudent = uncompletedStudents[currentStudentIndex];
  const isLastStudent = currentStudentIndex === uncompletedStudents.length - 1;

  // Safety check for current student
  if (!currentStudent) {
    return (
      <Card>
        <CardContent className="text-center py-8">
          <p className="text-muted-foreground">Ingen studerende fundet eller ugyldigt indeks</p>
        </CardContent>
      </Card>
    );
  }

  // Reset state when student changes
  useEffect(() => {
    setExamState('waiting');
    setDrawnQuestion(null);
    resetTimer(exam.examDurationMinutes);
    setNotes(currentStudent?.notes || '');
    setGrade(currentStudent?.grade || '');
  }, [currentStudentIndex]);

  // Draw question
  const handleDrawQuestion = () => {
    const questionNumber = drawRandomQuestion(exam.numberOfQuestions);
    setDrawnQuestion(questionNumber);
    setExamState('question-drawn');
  };

  // Start examination
  const handleStartExamination = () => {
    setExamState('in-progress');
    startTimer();
  };

  // Stop examination
  const handleStopExamination = () => {
    stopTimer();
    setExamState('finished');
  };

  // Submit grade and persist data
  const handleGradeSubmit = async () => {
    if (!grade.trim()) return;
    
    setIsSubmitting(true);
    try {
      // Preserve all existing student data and only update exam results
      const updatedStudent = await updateStudent(currentStudent.id, {
        ...currentStudent,
        questionNo: drawnQuestion!,
        examDurationMinutes: Math.ceil(actualExamTime / 60),
        notes: notes.trim(),
        grade: grade.trim()
      });
      
      if (updatedStudent) {
        handleStudentUpdate(updatedStudent);
        
        // Continue to next student or complete exam
        if (isLastStudent) {
          handleExamComplete();
        } else {
          handleNextStudent(uncompletedStudents);
        }
      }
    } catch (error) {
      console.error('Fejl ved gemning af eksamen data:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Current Student Info */}
      <StudentInfoCard
        student={currentStudent}
        currentIndex={currentStudentIndex}
        totalStudents={uncompletedStudents.length}
      />

      {/* Question Drawing */}
      {examState === 'waiting' && (
        <QuestionDrawingCard
          numberOfQuestions={exam.numberOfQuestions}
          onDrawQuestion={handleDrawQuestion}
        />
      )}

      {/* Question Result - Always show when question is drawn */}
      {drawnQuestion !== null && (
        <QuestionResultCard
          questionNumber={drawnQuestion}
        />
      )}

      {/* Start Examination */}
      {examState === 'question-drawn' && (
        <StartExamCard
          examDurationMinutes={exam.examDurationMinutes}
          onStartExamination={handleStartExamination}
        />
      )}

      {/* Timer and Controls */}
      {(examState === 'in-progress' || examState === 'finished') && (
        <TimerControlsCard
          timeRemaining={timeRemaining}
          actualExamTime={actualExamTime}
          examState={examState}
          onStopExamination={handleStopExamination}
          formatTime={formatTime}
          getTimerColor={() => getTimerColor(timeRemaining)}
        />
      )}

      {/* Notes during examination */}
      {(examState === 'in-progress' || examState === 'finished') && (
        <NotesCard
          notes={notes}
          examState={examState}
          onNotesChange={setNotes}
        />
      )}

      {/* Grading - Only show after examination is stopped */}
      {examState === 'finished' && (
        <GradingCard
          grade={grade}
          drawnQuestion={drawnQuestion}
          actualExamTime={actualExamTime}
          notes={notes}
          isLastStudent={isLastStudent}
          isSubmitting={isSubmitting}
          onGradeChange={setGrade}
          onSubmit={handleGradeSubmit}
        />
      )}

      {/* Time up notification */}
      {timeRemaining === 0 && examState === 'in-progress' && (
        <TimeUpNotification onStopExamination={handleStopExamination} />
      )}
    </div>
  );
} 