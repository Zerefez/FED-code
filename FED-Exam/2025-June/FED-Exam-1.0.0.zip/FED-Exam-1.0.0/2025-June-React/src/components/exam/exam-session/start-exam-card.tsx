import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Play } from 'lucide-react';

interface StartExamCardProps {
  examDurationMinutes: number;
  onStartExamination: () => void;
}

export function StartExamCard({ examDurationMinutes, onStartExamination }: StartExamCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Trin 2: Start eksamination</CardTitle>
        <CardDescription>
          Eksaminationstid: {examDurationMinutes} minutter. Timeren starter nedtælling.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Button onClick={onStartExamination} size="lg" className="w-full gap-2">
          <Play className="h-4 w-4" />
          Start eksamination
        </Button>
      </CardContent>
    </Card>
  );
} 