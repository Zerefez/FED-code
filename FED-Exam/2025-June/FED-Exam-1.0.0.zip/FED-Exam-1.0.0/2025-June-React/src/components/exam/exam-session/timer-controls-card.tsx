import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Square, Timer } from 'lucide-react';

interface TimerControlsCardProps {
  timeRemaining: number;
  actualExamTime: number;
  examState: 'in-progress' | 'finished';
  onStopExamination: () => void;
  formatTime: (seconds: number) => string;
  getTimerColor: () => string;
}

export function TimerControlsCard({
  timeRemaining,
  actualExamTime,
  examState,
  onStopExamination,
  formatTime,
  getTimerColor
}: TimerControlsCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Timer className="h-5 w-5" />
          Eksaminationstimer
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center">
          <div className={`text-4xl font-bold ${getTimerColor()}`}>
            {formatTime(timeRemaining)}
          </div>
          <p className="text-sm text-muted-foreground">Tid tilbage</p>
          <p className="text-sm text-muted-foreground">
            Faktisk eksaminationstid: {formatTime(actualExamTime)}
          </p>
        </div>
        
        {examState === 'in-progress' && (
          <Button onClick={onStopExamination} size="lg" className="w-full gap-2" variant="destructive">
            <Square className="h-4 w-4" />
            Slut eksamination
          </Button>
        )}

        {examState === 'finished' && (
          <div className="text-center p-4 bg-green-50 rounded-md border border-green-200">
            <p className="text-green-700 font-medium">Eksaminationen er afsluttet</p>
            <p className="text-sm text-green-600">Faktisk tid brugt: {formatTime(actualExamTime)}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
} 