import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { formatDate } from '@/lib/utils';
import type { Exam } from '@/types/exam';
import { Calendar, Clock, FileText, Plus } from 'lucide-react';

interface ExamListProps {
  exams: Exam[];
  loading: boolean;
  onCreateExam: () => void;
  onSelectExam: (exam: Exam) => void;
}

export function ExamList({ exams, loading: isLoading, onCreateExam, onSelectExam }: ExamListProps) {
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <p className="text-muted-foreground">Indlæser eksamener...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Mundtlige eksamener</h1>
          <p className="text-muted-foreground">
            Administrer dine mundtlige eksamener og studerende
          </p>
        </div>
        <Button onClick={onCreateExam} className="gap-2">
          <Plus className="h-4 w-4" />
          Opret eksamen
        </Button>
      </div>

      {exams.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">Ingen eksamener endnu</h3>
            <p className="text-muted-foreground mb-4">
              Kom i gang ved at oprette din første mundtlige eksamen
            </p>
            <Button onClick={onCreateExam} className="gap-2">
              <Plus className="h-4 w-4" />
              Opret eksamen
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {exams.map((exam) => (
            <Card 
              key={exam.id} 
              className="cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => onSelectExam(exam)}
            >
              <CardHeader>
                <CardTitle className="text-lg">{exam.courseName}</CardTitle>
                <CardDescription className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  {formatDate(exam.date)}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  <span>{exam.startTime} • {exam.examDurationMinutes} min</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <FileText className="h-4 w-4" />
                  <span>{exam.numberOfQuestions} spørgsmål</span>
                </div>
                <div className="text-sm font-medium text-primary">
                  {exam.examtermin}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
} 