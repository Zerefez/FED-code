import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface NotesCardProps {
  notes: string;
  examState: 'in-progress' | 'finished';
  onNotesChange: (notes: string) => void;
}

export function NotesCard({ notes, examState, onNotesChange }: NotesCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Trin 3: Noter til eksaminationen</CardTitle>
        <CardDescription>
          {examState === 'in-progress' 
            ? 'Indtast noter mens eksaminationen foregår' 
            : 'Rediger noter eller tilføj yderligere kommentarer'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <textarea
          className="w-full min-h-32 p-3 border rounded-md resize-y"
          placeholder="Indtast noter her..."
          value={notes}
          onChange={(e) => onNotesChange(e.target.value)}
          disabled={false} // Always allow note editing during and after exam
        />
      </CardContent>
    </Card>
  );
} 