export interface Exam {
  id: string;
  examtermin: string;
  courseName: string;
  date: string;
  numberOfQuestions: number;
  examDurationMinutes: number;
  startTime: string;
}

export interface Student {
  id: string;
  exam: string;
  studenNo: string;
  firstName: string;
  lastName: string;
  questionNo?: number;
  examDurationMinutes?: number;
  notes?: string;
  grade?: string;
}

export interface CreateStudentData {
  studenNo: string;
  firstName: string;
  lastName: string;
}

export interface CreateExamData {
  examtermin: string;
  courseName: string;
  date: string;
  numberOfQuestions: number;
  examDurationMinutes: number;
  startTime: string;
} 