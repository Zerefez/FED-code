import type { Student } from '../types/exam';
import { apiClient } from './api-client';

export const studentService = {
  // Create a new student
  createStudent: async (studentData: Omit<Student, 'id'>): Promise<Student> => {
    return apiClient.post<Student>('/students', studentData);
  },

  // Get all students
  getStudents: async (): Promise<Student[]> => {
    return apiClient.get<Student[]>('/students');
  },

  // Get students by exam ID
  getStudentsByExam: async (examId: string): Promise<Student[]> => {
    return apiClient.get<Student[]>('/students', { exam: examId });
  },

  // Get a specific student by ID
  getStudent: async (id: string): Promise<Student> => {
    return apiClient.get<Student>(`/students/${id}`);
  },

  // Update a student
  updateStudent: async (id: string, studentData: Partial<Student>): Promise<Student> => {
    return apiClient.patch<Student>(`/students/${id}`, studentData);
  },

  // Delete a student
  deleteStudent: async (id: string): Promise<void> => {
    return apiClient.delete<void>(`/students/${id}`);
  },
}; 