import type { CreateExamData, Exam } from '../types/exam';
import { apiClient } from './api-client';

export const examService = {
  // Create a new exam
  createExam: async (examData: CreateExamData): Promise<Exam> => {
    return apiClient.post<Exam>('/exams', examData);
  },

  // Get all exams
  getExams: async (): Promise<Exam[]> => {
    return apiClient.get<Exam[]>('/exams');
  },

  // Get a specific exam by ID
  getExam: async (id: string): Promise<Exam> => {
    return apiClient.get<Exam>(`/exams/${id}`);
  },

  // Update an exam
  updateExam: async (id: string, examData: Partial<Exam>): Promise<Exam> => {
    return apiClient.put<Exam>(`/exams/${id}`, examData);
  },

  // Delete an exam
  deleteExam: async (id: string): Promise<void> => {
    return apiClient.delete<void>(`/exams/${id}`);
  },
}; 