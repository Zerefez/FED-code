import { useExamData } from '@/hooks/useExamData';
import type { Exam, Student } from '@/types/exam';
import React, { createContext, ReactNode, useContext } from 'react';

interface ExamContextType {
  // Data
  exam: Exam | null;
  students: Student[];
  isLoading: boolean;
  completedStudentsCount: number;
  uncompletedStudents: Student[];
  
  // Actions
  handleStudentAdded: (student: Student) => void;
  handleStudentUpdate: (student: Student) => void;
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
}

const ExamContext = createContext<ExamContextType | undefined>(undefined);

interface ExamProviderProps {
  children: ReactNode;
  examId: string | undefined;
}

export function ExamProvider({ children, examId }: ExamProviderProps) {
  const examData = useExamData(examId);

  return (
    <ExamContext.Provider value={examData}>
      {children}
    </ExamContext.Provider>
  );
}

export function useExamContext() {
  const context = useContext(ExamContext);
  if (context === undefined) {
    throw new Error('useExamContext must be used within an ExamProvider');
  }
  return context;
} 