import { useExamSession } from '@/hooks/useExamSession';
import type { Student } from '@/types/exam';
import { createContext, ReactNode, useContext } from 'react';

type PageState = 'overview' | 'adding-students' | 'exam-running' | 'exam-completed';

interface ExamSessionContextType {
  // State
  pageState: PageState;
  currentStudentIndex: number;
  
  // Actions
  setPageState: (state: PageState) => void;
  setCurrentStudentIndex: (index: number) => void;
  handleStartExam: (students: Student[]) => void;
  handleNextStudent: (students: Student[]) => void;
  handleExamComplete: () => void;
  handleShowStudentForm: () => void;
  handleStudentFormCancel: () => void;
}

const ExamSessionContext = createContext<ExamSessionContextType | undefined>(undefined);

interface ExamSessionProviderProps {
  children: ReactNode;
}

export function ExamSessionProvider({ children }: ExamSessionProviderProps) {
  const sessionData = useExamSession();

  return (
    <ExamSessionContext.Provider value={sessionData}>
      {children}
    </ExamSessionContext.Provider>
  );
}

export function useExamSessionContext() {
  const context = useContext(ExamSessionContext);
  if (context === undefined) {
    throw new Error('useExamSessionContext must be used within an ExamSessionProvider');
  }
  return context;
} 