import { completionLock } from '@/lib/utils';
import type { Student } from '@/types/exam';
import { useEffect, useRef, useState } from 'react';

type PageState = 'overview' | 'adding-students' | 'exam-running' | 'exam-completed';

interface UseExamSessionReturn {
  pageState: PageState;
  currentStudentIndex: number;
  setPageState: (state: PageState) => void;
  setCurrentStudentIndex: (index: number) => void;
  handleStartExam: (students: Student[]) => void;
  handleNextStudent: (students: Student[]) => void;
  handleExamComplete: () => void;
  handleShowStudentForm: () => void;
  handleStudentFormCancel: () => void;
}

export function useExamSession(): UseExamSessionReturn {
  // Initialize state - if completion is locked, start with exam-completed
  const [pageState, setPageState] = useState<PageState>(() => {
    return completionLock.isLocked() ? 'exam-completed' : 'overview';
  });
  
  const [currentStudentIndex, setCurrentStudentIndex] = useState(0);
  const completionLockRef = useRef(completionLock.isLocked());

  // Maintain completion state if locked
  useEffect(() => {
    if (completionLock.isLocked() && pageState !== 'exam-completed') {
      setPageState('exam-completed');
    }
  }, [pageState]);

  // Protected setPageState to prevent changes when completion is locked
  const protectedSetPageState = (newState: PageState) => {
    if (completionLock.isLocked() && newState !== 'exam-completed') {
      return; // Don't allow state changes away from completion
    }
    setPageState(newState);
  };

  const handleStartExam = (students: Student[]) => {
    if (students.length === 0) {
      alert('Du skal tilføje mindst én studerende før eksamen kan startes.');
      return;
    }
    
    // Filter out students who have already been graded
    const uncompletedStudents = students.filter(student => !student.grade);
    
    if (uncompletedStudents.length === 0) {
      alert('Alle studerende har allerede gennemført eksamen.');
      return;
    }
    
    // Clear completion lock when starting new exam
    completionLock.unlock();
    completionLockRef.current = false;
    setCurrentStudentIndex(0);
    setPageState('exam-running');
  };

  const handleNextStudent = (students: Student[]) => {
    if (completionLock.isLocked()) return; // Don't allow navigation when completed
    
    // Get only uncompleted students
    const uncompletedStudents = students.filter(student => !student.grade);
    
    if (currentStudentIndex < uncompletedStudents.length - 1) {
      setCurrentStudentIndex(prev => prev + 1);
    }
  };

  const handleExamComplete = () => {
    // Set completion lock and state
    completionLock.lock();
    completionLockRef.current = true;
    setPageState('exam-completed');
    
    // Extra safety to ensure completion state persists
    setTimeout(() => {
      if (completionLock.isLocked()) {
        setPageState('exam-completed');
      }
    }, 10);
  };

  const handleShowStudentForm = () => {
    if (!completionLock.isLocked()) {
      protectedSetPageState('adding-students');
    }
  };

  const handleStudentFormCancel = () => {
    if (!completionLock.isLocked()) {
      protectedSetPageState('overview');
    }
  };

  return {
    pageState,
    currentStudentIndex,
    setPageState: protectedSetPageState,
    setCurrentStudentIndex,
    handleStartExam,
    handleNextStudent,
    handleExamComplete,
    handleShowStudentForm,
    handleStudentFormCancel,
  };
} 