import { examService } from '@/services/exam-service';
import type { CreateExamData, Exam } from '@/types/exam';
import { useCrud } from './useCrud';

// Adapter to match the CRUD service interface
const examCrudService = {
  getAll: examService.getExams,
  getById: examService.getExam,
  create: examService.createExam,
  update: examService.updateExam,
  delete: examService.deleteExam,
};

export function useExams() {
  return useCrud<Exam, CreateExamData>(examCrudService);
} 