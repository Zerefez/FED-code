import { studentService } from '@/services/student-service';
import type { Student } from '@/types/exam';
import { useCrud } from './useCrud';

// Adapter to match the CRUD service interface
const studentCrudService = {
  getAll: studentService.getStudents,
  getById: studentService.getStudent,
  create: studentService.createStudent,
  update: studentService.updateStudent,
  delete: studentService.deleteStudent,
};

export function useStudents() {
  const crud = useCrud<Student>(studentCrudService);

  return {
    ...crud,

    getByExam: studentService.getStudentsByExam,
  };
} 