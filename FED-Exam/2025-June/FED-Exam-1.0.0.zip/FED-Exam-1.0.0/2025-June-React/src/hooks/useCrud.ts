import { useEffect, useState } from 'react';

interface CrudService<T, CreateData = Omit<T, 'id'>> {
  getAll: () => Promise<T[]>;
  getById: (id: string) => Promise<T>;
  create: (data: CreateData) => Promise<T>;
  update: (id: string, data: Partial<T>) => Promise<T>;
  delete: (id: string) => Promise<void>;
}

interface UseCrudReturn<T, CreateData> {
  items: T[];
  loading: boolean;
  error: string | null;
  
  // Actions
  load: () => Promise<void>;
  create: (data: CreateData) => Promise<T | null>;
  update: (id: string, data: Partial<T>) => Promise<T | null>;
  remove: (id: string) => Promise<boolean>;
  
  // Utils
  getById: (id: string) => T | undefined;
  refresh: () => Promise<void>;
}

export function useCrud<T extends { id: string }, CreateData = Omit<T, 'id'>>(
  service: CrudService<T, CreateData>
): UseCrudReturn<T, CreateData> {
  const [items, setItems] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await service.getAll();
      setItems(data);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load items';
      setError(message);
      console.error('Error loading items:', err);
    } finally {
      setLoading(false);
    }
  };

  const create = async (data: CreateData): Promise<T | null> => {
    setError(null);
    
    try {
      const newItem = await service.create(data);
      setItems(prev => [...prev, newItem]);
      return newItem;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to create item';
      setError(message);
      console.error('Error creating item:', err);
      return null;
    }
  };

  const update = async (id: string, data: Partial<T>): Promise<T | null> => {
    setError(null);
    
    try {
      const updatedItem = await service.update(id, data);
      setItems(prev => prev.map(item => item.id === id ? updatedItem : item));
      return updatedItem;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to update item';
      setError(message);
      console.error('Error updating item:', err);
      return null;
    }
  };

  const remove = async (id: string): Promise<boolean> => {
    setError(null);
    
    try {
      await service.delete(id);
      setItems(prev => prev.filter(item => item.id !== id));
      return true;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to delete item';
      setError(message);
      console.error('Error deleting item:', err);
      return false;
    }
  };

  const getById = (id: string): T | undefined => {
    return items.find(item => item.id === id);
  };

  const refresh = async () => {
    await load();
  };

  // Auto-load on mount
  useEffect(() => {
    load();
  }, []); // Only run on mount

  return {
    items,
    loading,
    error,
    load,
    create,
    update,
    remove,
    getById,
    refresh,
  };
} 