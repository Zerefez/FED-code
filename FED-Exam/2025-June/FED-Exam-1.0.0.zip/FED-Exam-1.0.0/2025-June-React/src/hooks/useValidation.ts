import { isRequired } from '@/lib/utils';
import { useState } from 'react';

export interface ValidationRule<T> {
  field: keyof T;
  validator: (value: any, data: T) => string | null;
  message?: string;
}

export function useValidation<T>() {
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = (data: T, rules: ValidationRule<T>[]): boolean => {
    const newErrors: Record<string, string> = {};
    let isValid = true;

    rules.forEach(rule => {
      const fieldValue = data[rule.field];
      const error = rule.validator(fieldValue, data);
      
      if (error) {
        newErrors[rule.field as string] = error;
        isValid = false;
      }
    });

    setErrors(newErrors);
    return isValid;
  };

  const clearErrors = () => setErrors({});
  
  const clearError = (field: keyof T) => {
    setErrors(prev => {
      const newErrors = { ...prev };
      delete newErrors[field as string];
      return newErrors;
    });
  };

  return {
    errors,
    validate,
    clearErrors,
    clearError,
  };
}

// Common validators
export const validators = {
  required: (value: any) => isRequired(value) ? 'Dette felt er påkrævet' : null,
  min: (minValue: number) => (value: any) => {
    const numValue = typeof value === 'string' ? parseInt(value) : value;
    return (isNaN(numValue) || numValue < minValue) ? `Værdien skal være mindst ${minValue}` : null;
  },
}; 