import { useState } from 'react';

interface UseFormReturn<T> {
  data: T;
  errors: Record<string, string>;
  loading: boolean;
  
  set: (field: keyof T, value: any) => void;
  setData: (newData: T) => void;
  setError: (field: keyof T, error: string) => void;
  clearError: (field: keyof T) => void;
  clearErrors: () => void;
  reset: () => void;
  
  handleSubmit: (onSubmit: (data: T) => Promise<void> | void) => (e: React.FormEvent) => Promise<void>;
}

export function useForm<T>(initialData: T): UseFormReturn<T> {
  const [data, setData] = useState<T>(initialData);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const set = (field: keyof T, value: any) => {
    setData(prev => ({ ...prev, [field]: value }));
    if (errors[field as string]) {
      clearError(field);
    }
  };

  const setFormData = (newData: T) => {
    setData(newData);
  };

  const setError = (field: keyof T, error: string) => {
    setErrors(prev => ({ ...prev, [field as string]: error }));
  };

  const clearError = (field: keyof T) => {
    setErrors(prev => {
      const newErrors = { ...prev };
      delete newErrors[field as string];
      return newErrors;
    });
  };

  const clearErrors = () => {
    setErrors({});
  };

  const reset = () => {
    setData(initialData);
    setErrors({});
    setLoading(false);
  };

  const handleSubmit = (onSubmit: (data: T) => Promise<void> | void) => {
    return async (e: React.FormEvent) => {
      e.preventDefault();
      setLoading(true);
      clearErrors();
      
      try {
        await onSubmit(data);
      } catch (error) {
        console.error('Form submission error:', error);
      } finally {
        setLoading(false);
      }
    };
  };

  return {
    data,
    errors,
    loading,
    set,
    setData: setFormData,
    setError,
    clearError,
    clearErrors,
    reset,
    handleSubmit,
  };
} 