﻿using Microsoft.Extensions.Logging;
using _2025JuneMAUI.Data;
using _2025JuneMAUI.ViewModels;
using _2025JuneMAUI.Views;
using _2025JuneMAUI.Services;

namespace _2025JuneMAUI;

public static class MauiProgram
{
	public static MauiApp CreateMauiApp()
	{
		var builder = MauiApp.CreateBuilder();
		builder
			.UseMauiApp<App>()
			.ConfigureFonts(fonts =>
			{
				fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
				fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
			});

		// Register Database as a singleton service
		builder.Services.AddSingleton<Database>();
		
		// Register Core Services
		builder.Services.AddSingleton<IDialogService, DialogService>();
		builder.Services.AddSingleton<IDataService, DataService>();
		builder.Services.AddTransient<ITimerService, TimerService>();
		
		// Register Business Services
		builder.Services.AddTransient<IExamService, ExamService>();
		builder.Services.AddTransient<IStudentService, StudentService>();
		builder.Services.AddTransient<IExamSessionService, ExamSessionService>();
		
		// Note: ValidationService and GradeCalculationService are static utility classes
		// and don't require DI registration
		
		// Register ViewModels
		builder.Services.AddTransient<ExamViewModel>();
		builder.Services.AddTransient<StudentViewModel>();
		builder.Services.AddTransient<ExamSessionViewModel>();
		builder.Services.AddTransient<HistoryViewModel>();
		
		// Register Pages
		builder.Services.AddTransient<ExamPage>();
		builder.Services.AddTransient<StudentPage>();
		builder.Services.AddTransient<ExamSessionPage>();
		builder.Services.AddTransient<HistoryPage>();

#if DEBUG
		builder.Logging.AddDebug();
#endif

		return builder.Build();
	}
}
