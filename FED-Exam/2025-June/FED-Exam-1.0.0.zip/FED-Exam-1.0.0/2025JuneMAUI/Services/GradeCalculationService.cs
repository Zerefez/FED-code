using _2025JuneMAUI.Models;

namespace _2025JuneMAUI.Services
{
    public static class GradeCalculationService
    {
        private static readonly Dictionary<string, int> GradeValues = new() 
        { 
            { "-3", -3 }, { "00", 0 }, { "02", 2 }, { "4", 4 }, { "7", 7 }, { "10", 10 }, { "12", 12 } 
        };

        public static string CalculateAverageGrade(IEnumerable<Student> students)
        {
            var completedStudents = students.Where(s => !string.IsNullOrEmpty(s.Grade)).ToList();
            if (!completedStudents.Any()) return "N/A";

            var gradeValues = completedStudents
                .Where(s => GradeValues.ContainsKey(s.Grade))
                .Select(s => GradeValues[s.Grade])
                .ToList();

            return gradeValues.Any() ? gradeValues.Average().ToString("F1") : "N/A";
        }

        public static Dictionary<string, int> GetGradeDistribution(IEnumerable<Student> students)
        {
            var distribution = GradeValues.Keys.ToDictionary(grade => grade, _ => 0);
            
            foreach (var student in students.Where(s => !string.IsNullOrEmpty(s.Grade)))
            {
                if (distribution.ContainsKey(student.Grade))
                    distribution[student.Grade]++;
            }
            
            return distribution;
        }

        public static double CalculateNumericalAverage(IEnumerable<Student> students)
        {
            var gradeValues = students
                .Where(s => !string.IsNullOrEmpty(s.Grade) && GradeValues.ContainsKey(s.Grade))
                .Select(s => GradeValues[s.Grade])
                .ToList();

            return gradeValues.Any() ? gradeValues.Average() : 0.0;
        }
    }
} 