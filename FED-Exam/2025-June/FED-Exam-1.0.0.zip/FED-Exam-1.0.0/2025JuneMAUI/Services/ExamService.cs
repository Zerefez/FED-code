using _2025JuneMAUI.Models;

namespace _2025JuneMAUI.Services
{
    public class ExamService : IExamService
    {
        private readonly IDataService _dataService;
        private readonly IDialogService _dialogService;

        public ExamService(IDataService dataService, IDialogService dialogService) => (_dataService, _dialogService) = (dataService, dialogService);

        public async Task<List<Exam>> GetAllExamsAsync() => await _dataService.GetExamsAsync();

        public async Task<Exam> CreateExamAsync(string termim, string courseName, string date, int questions, int duration, string startTime)
        {
            if (!await ValidateExamDataAsync(termim, courseName, questions, duration)) 
                throw new ArgumentException("Ugyldig eksamen data");

            var exam = new Exam { ExamTermin = termim, CourseName = courseName, Date = date, NumberOfQuestions = questions, ExamDurationMinutes = duration, StartTime = startTime };
            await _dataService.AddExamAsync(exam);
            await _dialogService.ShowAlertAsync("Succes", "Eksamen oprettet!");
            return exam;
        }

        public async Task<Exam> UpdateExamAsync(int id, string termim, string courseName, string date, int questions, int duration, string startTime)
        {
            if (!await ValidateExamDataAsync(termim, courseName, questions, duration)) 
                throw new ArgumentException("Ugyldig eksamen data");

            var exam = await _dataService.GetExamAsync(id) ?? throw new InvalidOperationException("Eksamen ikke fundet");
            (exam.ExamTermin, exam.CourseName, exam.Date, exam.NumberOfQuestions, exam.ExamDurationMinutes, exam.StartTime) = (termim, courseName, date, questions, duration, startTime);
            await _dataService.UpdateExamAsync(exam);
            await _dialogService.ShowAlertAsync("Succes", "Eksamen opdateret!");
            return exam;
        }

        public async Task<bool> DeleteExamAsync(int examId)
        {
            var exam = await _dataService.GetExamAsync(examId);
            if (exam == null) return false;

            if (await _dialogService.ShowConfirmAsync("Bekræft", $"Slet eksamen '{exam.CourseName}'? Dette sletter også alle tilknyttede studerende."))
            {
                await _dataService.DeleteExamAsync(exam);
                await _dialogService.ShowAlertAsync("Succes", "Eksamen slettet!");
                return true;
            }
            return false;
        }

        public async Task<bool> ValidateExamDataAsync(string termim, string courseName, int questions, int duration) =>
            await ValidationService.ValidateAsync(_dialogService, ValidationService.GetExamValidations(termim, courseName, questions, duration));
    }
} 