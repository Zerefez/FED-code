using _2025JuneMAUI.Data;
using _2025JuneMAUI.Models;

namespace _2025JuneMAUI.Services
{
    public class DataService : IDataService
    {
        private readonly Database _database;

        public DataService(Database database) => _database = database;

        public async Task<List<Exam>> GetExamsAsync() => await _database.GetExamsAsync();
        public async Task<Exam?> GetExamAsync(int id) => await _database.GetExamAsync(id);
        public async Task<int> AddExamAsync(Exam exam) => await _database.AddExamAsync(exam);
        public async Task<int> UpdateExamAsync(Exam exam) => await _database.UpdateExamAsync(exam);
        public async Task<int> DeleteExamAsync(Exam exam) => await _database.DeleteExamAsync(exam);

        public async Task<List<Student>> GetStudentsByExamIdAsync(int examId) => await _database.GetStudentsByExamIdAsync(examId);
        public async Task<Student?> GetStudentAsync(int id) => await _database.GetStudentAsync(id);
        public async Task<int> AddStudentAsync(Student student) => await _database.AddStudentAsync(student);
        public async Task<int> UpdateStudentAsync(Student student) => await _database.UpdateStudentAsync(student);
        public async Task<int> DeleteStudentAsync(Student student) => await _database.DeleteStudentAsync(student);

        public async Task<int> GetNextExaminationOrderAsync(int examId) => await _database.GetNextExaminationOrderAsync(examId);
        public async Task<int> GetTotalStudentsForExamAsync(int examId) => await _database.GetTotalStudentsForExamAsync(examId);
        public async Task<int> GetCompletedStudentsForExamAsync(int examId) => await _database.GetCompletedStudentsForExamAsync(examId);

        public async Task<double> GetExamAverageGradeAsync(int examId)
        {
            var students = await _database.GetStudentsByExamIdAsync(examId);
            var completedStudents = students.Where(s => !string.IsNullOrEmpty(s.Grade)).ToList();
            
            if (!completedStudents.Any()) return 0;

            var gradeValues = new Dictionary<string, int> { { "-3", -3 }, { "00", 0 }, { "02", 2 }, { "4", 4 }, { "7", 7 }, { "10", 10 }, { "12", 12 } };
            var validGrades = completedStudents.Where(s => gradeValues.ContainsKey(s.Grade)).ToList();
            
            return validGrades.Any() ? validGrades.Average(s => gradeValues[s.Grade]) : 0;
        }
    }
} 