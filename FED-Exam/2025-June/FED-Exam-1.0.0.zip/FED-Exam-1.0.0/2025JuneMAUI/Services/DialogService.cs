namespace _2025JuneMAUI.Services
{
    public class DialogService : IDialogService
    {
        public async Task ShowAlertAsync(string title, string message) => await Shell.Current.DisplayAlert(title, message, "OK");

        public async Task<bool> ShowConfirmAsync(string title, string message) => await Shell.Current.DisplayAlert(title, message, "Ja", "Nej");
    }
} 