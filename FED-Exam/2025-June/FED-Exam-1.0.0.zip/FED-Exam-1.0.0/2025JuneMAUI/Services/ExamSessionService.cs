using _2025JuneMAUI.Models;

namespace _2025JuneMAUI.Services
{
    public class ExamSessionService : IExamSessionService
    {
        private readonly IDataService _dataService;
        private readonly IDialogService _dialogService;
        private readonly Random _random = new();
        private readonly string[] _danishGrades = { "-3", "00", "02", "4", "7", "10", "12" };

        public ExamSessionService(IDataService dataService, IDialogService dialogService) => (_dataService, _dialogService) = (dataService, dialogService);

        public async Task<List<Student>> GetStudentsForExamAsync(int examId) => await _dataService.GetStudentsByExamIdAsync(examId);

        public async Task<Student?> GetCurrentStudentAsync(int examId, int currentIndex)
        {
            var students = await GetStudentsForExamAsync(examId);
            return currentIndex < students.Count ? students[currentIndex] : null;
        }

        public async Task<Student?> FindFirstUncompletedStudentAsync(int examId) => 
            (await GetStudentsForExamAsync(examId)).FirstOrDefault(s => string.IsNullOrEmpty(s.Grade));

        public int DrawRandomQuestion(int maxQuestions) => _random.Next(1, maxQuestions + 1);
        public string[] GetAvailableGrades() => _danishGrades;
        public string FormatTime(int totalSeconds) => $"{totalSeconds / 60:D2}:{totalSeconds % 60:D2}";

        public string GetTimerColor(int remainingSeconds, int totalDurationSeconds)
        {
            var percentage = (double)remainingSeconds / totalDurationSeconds;
            return percentage switch
            {
                > 0.5 => "#22C55E", // Green
                > 0.25 => "#F59E0B", // Orange
                _ => "#DC2626" // Red
            };
        }

        public async Task SaveStudentExamDataAsync(Student student, int questionNumber, int actualTimeMinutes, string notes, string grade)
        {
            student.QuestionNo = questionNumber;
            student.ExamDurationMinutes = actualTimeMinutes;
            student.Notes = notes;
            student.Grade = grade;
            
            await _dataService.UpdateStudentAsync(student);
            await _dialogService.ShowAlertAsync("Gemt", $"Data gemt for {student.FirstName} {student.LastName}");
        }

        public async Task<(int Total, int Completed, string Stats)> GetExamProgressAsync(int examId)
        {
            var students = await GetStudentsForExamAsync(examId);
            var completed = students.Count(s => !string.IsNullOrEmpty(s.Grade));
            var average = GradeCalculationService.CalculateAverageGrade(students);
            return (students.Count, completed, $"Gennemsnit: {average}");
        }

        public bool IsStudentCompleted(Student student) => !string.IsNullOrEmpty(student.Grade);

        public async Task<string> GetStudentSummaryAsync(Student student)
        {
            var exam = await _dataService.GetExamAsync(student.ExamId);
            return $"""
                ✅ EKSAMEN GENNEMFØRT
                
                {student.FirstName} {student.LastName}
                Studienummer: {student.StudentNo}
                
                📝 Eksamen: {exam?.CourseName ?? "Ukendt"}
                🎯 Spørgsmål: {student.QuestionNo}
                ⏱️ Tid: {student.ExamDurationMinutes} min
                📊 Karakter: {student.Grade}
                
                📋 Noter:
                {(string.IsNullOrEmpty(student.Notes) ? "Ingen noter" : student.Notes)}
                """;
        }

        public async Task<bool> HasUncompletedStudentsAsync(int examId) => 
            (await GetStudentsForExamAsync(examId)).Any(s => string.IsNullOrEmpty(s.Grade));

        public async Task<string> GetExamCompletionSummaryAsync(int examId)
        {
            var students = await GetStudentsForExamAsync(examId);
            var completedStudents = students.Where(s => !string.IsNullOrEmpty(s.Grade)).ToList();
            var average = GradeCalculationService.CalculateNumericalAverage(students);
            var distribution = GradeCalculationService.GetGradeDistribution(students);
            
            return $"""
                🎉 EKSAMEN AFSLUTTET
                
                📊 Status: {completedStudents.Count}/{students.Count} gennemført
                📈 Gennemsnit: {average:F1}
                
                📋 Karakterfordeling:
                {string.Join("\n", distribution.Where(kvp => kvp.Value > 0).Select(kvp => $"  {kvp.Key}: {kvp.Value}"))}
                """;
        }
    }
} 