using _2025JuneMAUI.Services;

namespace _2025JuneMAUI.Services
{
    public static class ValidationService
    {
        public static async Task<bool> ValidateAsync(IDialogService dialogService, params (bool isInvalid, string message)[] validations)
        {
            foreach (var (isInvalid, message) in validations)
            {
                if (isInvalid) 
                { 
                    await dialogService.ShowAlertAsync("Fejl", message); 
                    return false; 
                }
            }
            return true;
        }

        public static (bool isInvalid, string message)[] GetExamValidations(string termim, string courseName, int questions, int duration) =>
            new[] {
                (string.IsNullOrWhiteSpace(termim), "Eksamenstermin er påkrævet"),
                (string.IsNullOrWhiteSpace(courseName), "Kursusnavn er påkrævet"),
                (questions <= 0, "Antal spørgsmål skal være større end 0"),
                (duration <= 0, "Eksaminationstid skal være større end 0")
            };

        public static (bool isInvalid, string message)[] GetStudentValidations(int examId, string studentNo, string firstName, string lastName) =>
            new[] {
                (examId == 0, "Vælg venligst en eksamen først"),
                (string.IsNullOrWhiteSpace(studentNo), "Studienummer er påkrævet"),
                (string.IsNullOrWhiteSpace(firstName), "Fornavn er påkrævet"),
                (string.IsNullOrWhiteSpace(lastName), "Efternavn er påkrævet")
            };
    }
} 