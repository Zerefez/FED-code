using System.Timers;

namespace _2025JuneMAUI.Services
{
    public class TimerService : ITimerService, IDisposable
    {
        private System.Timers.Timer? _timer;
        private int _elapsedSeconds;
        private int _totalDurationSeconds;
        private bool _isRunning;
        private bool _isCountdownMode;

        public event EventHandler<int>? TimerTick;
        public bool IsRunning => _isRunning;
        public int ElapsedSeconds => _elapsedSeconds;
        public int RemainingSeconds => Math.Max(0, _totalDurationSeconds - _elapsedSeconds);
        public bool IsCountdownMode => _isCountdownMode;

        public void SetCountdownDuration(int totalMinutes)
        {
            _totalDurationSeconds = totalMinutes * 60;
            _isCountdownMode = true;
        }

        public void Start()
        {
            if (_isRunning) return;
            _timer ??= new System.Timers.Timer(1000) { AutoReset = true };
            _timer.Elapsed += OnTimerElapsed;
            _timer.Start();
            _isRunning = true;
        }

        public void Stop()
        {
            if (!_isRunning) return;
            _timer?.Stop();
            if (_timer != null) _timer.Elapsed -= OnTimerElapsed;
            _isRunning = false;
        }

        public void Reset()
        {
            Stop();
            (_elapsedSeconds, _totalDurationSeconds, _isCountdownMode) = (0, 0, false);
        }

        public string GetFormattedTime() => TimeSpan.FromSeconds(_elapsedSeconds).ToString(@"mm\:ss");
        public string GetFormattedRemainingTime() => TimeSpan.FromSeconds(RemainingSeconds).ToString(@"mm\:ss");
        public int GetElapsedMinutes() => _elapsedSeconds / 60;

        private void OnTimerElapsed(object? sender, ElapsedEventArgs e)
        {
            _elapsedSeconds++;
            var eventValue = _isCountdownMode ? RemainingSeconds : _elapsedSeconds;
            TimerTick?.Invoke(this, eventValue);
            
            if (_isCountdownMode && RemainingSeconds <= 0) Stop();
        }

        public void Dispose()
        {
            Stop();
            _timer?.Dispose();
        }
    }
} 