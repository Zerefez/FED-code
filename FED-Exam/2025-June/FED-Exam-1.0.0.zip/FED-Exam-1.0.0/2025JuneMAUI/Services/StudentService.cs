using _2025JuneMAUI.Models;

namespace _2025JuneMAUI.Services
{
    public class StudentService : IStudentService
    {
        private readonly IDataService _dataService;
        private readonly IDialogService _dialogService;

        public StudentService(IDataService dataService, IDialogService dialogService) => (_dataService, _dialogService) = (dataService, dialogService);

        public async Task<List<Student>> GetStudentsForExamAsync(int examId) => await _dataService.GetStudentsByExamIdAsync(examId);

        public async Task<Student> CreateStudentAsync(int examId, string studentNo, string firstName, string lastName, int order)
        {
            var student = new Student 
            { 
                ExamId = examId, 
                StudentNo = studentNo, 
                FirstName = firstName, 
                LastName = lastName, 
                ExaminationOrder = order 
            };
            await _dataService.AddStudentAsync(student);
            await _dialogService.ShowAlertAsync("Succes", "Studerende tilføjet!");
            return student;
        }

        public async Task<Student> UpdateStudentAsync(int id, string studentNo, string firstName, string lastName, int order)
        {
            var student = await _dataService.GetStudentAsync(id) ?? throw new InvalidOperationException("Studerende ikke fundet");
            (student.StudentNo, student.FirstName, student.LastName, student.ExaminationOrder) = (studentNo, firstName, lastName, order);
            await _dataService.UpdateStudentAsync(student);
            return student;
        }

        public async Task<bool> DeleteStudentAsync(int studentId)
        {
            var student = await _dataService.GetStudentAsync(studentId);
            if (student == null) return false;

            if (await _dialogService.ShowConfirmAsync("Bekræft", $"Slet studerende '{student.FirstName} {student.LastName}'?"))
            {
                await _dataService.DeleteStudentAsync(student);
                await _dialogService.ShowAlertAsync("Succes", "Studerende slettet!");
                return true;
            }
            return false;
        }

        public async Task SwapStudentOrdersAsync(int studentId1, int studentId2)
        {
            var (student1, student2) = (await _dataService.GetStudentAsync(studentId1), await _dataService.GetStudentAsync(studentId2));
            if (student1 == null || student2 == null) return;
            (student1.ExaminationOrder, student2.ExaminationOrder) = (student2.ExaminationOrder, student1.ExaminationOrder);
            await Task.WhenAll(_dataService.UpdateStudentAsync(student1), _dataService.UpdateStudentAsync(student2));
        }

        public async Task<bool> ValidateStudentDataAsync(int examId, string studentNo, string firstName, string lastName) =>
            await ValidationService.ValidateAsync(_dialogService, ValidationService.GetStudentValidations(examId, studentNo, firstName, lastName));

        public async Task<int> GetNextOrderAsync(int examId) => await _dataService.GetNextExaminationOrderAsync(examId);

        public async Task<string> GetExamStatsAsync(int examId)
        {
            var students = await GetStudentsForExamAsync(examId);
            var completedStudents = students.Where(s => !string.IsNullOrEmpty(s.Grade)).ToList();
            var average = GradeCalculationService.CalculateAverageGrade(students);
            return $"Total: {students.Count}, Gennemført: {completedStudents.Count}, Gennemsnit: {average}";
        }

        public string CalculateAverageGrade(List<Student> students) => GradeCalculationService.CalculateAverageGrade(students);

        public Dictionary<string, int> GetGradeDistribution(List<Student> students) => GradeCalculationService.GetGradeDistribution(students);
    }
} 