using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using _2025JuneMAUI.Models;
using _2025JuneMAUI.Services;
using System.Collections.ObjectModel;

namespace _2025JuneMAUI.ViewModels
{
    public partial class HistoryViewModel : BaseViewModel
    {
        private readonly IExamService _examService;
        private readonly IStudentService _studentService;

        [ObservableProperty] private Exam? selectedExam;
        [ObservableProperty] private string examSummary = string.Empty;
        [ObservableProperty] private string averageGrade = string.Empty;
        [ObservableProperty] private bool showStudentList;
        [ObservableProperty] private bool showNoDataMessage;
        [ObservableProperty] private string noDataMessage = string.Empty;

        public HistoryViewModel(IExamService examService, IStudentService studentService)
        {
            (_examService, _studentService) = (examService, studentService);
            Title = "Historik";
            (Exams, Students) = (new(), new());
            _ = LoadExams();
        }

        public ObservableCollection<Exam> Exams { get; }
        public ObservableCollection<Student> Students { get; }

        partial void OnSelectedExamChanged(Exam? value) 
        {
            if (value?.Id > 0) _ = LoadExamHistory(value);
        }

        [RelayCommand] 
        private async Task LoadExams() => await ExecuteAsync(async () =>
            UpdateCollectionFromList(Exams, await _examService.GetAllExamsAsync()));

        [RelayCommand] 
        private async Task LoadExamHistory(Exam exam) => await ExecuteAsync(async () =>
        {
            var allStudents = await _studentService.GetStudentsForExamAsync(exam.Id);
            var completedStudents = allStudents.Where(s => !string.IsNullOrEmpty(s.Grade)).ToList();
            
            if (!completedStudents.Any()) 
            { 
                ShowNoDataState("Ingen gennemførte eksamener fundet for denne eksamen."); 
                return; 
            }
            
            UpdateCollectionFromList(Students, completedStudents);
            
            ExamSummary = CreateExamSummary(exam, allStudents, completedStudents);
            AverageGrade = GradeCalculationService.CalculateAverageGrade(completedStudents);
            (ShowStudentList, ShowNoDataMessage) = (true, false);
        });

        [RelayCommand] 
        private async Task RefreshData()
        {
            await LoadExams();
            if (SelectedExam?.Id > 0) await LoadExamHistory(SelectedExam);
        }

        private void ResetDisplay() => (ShowStudentList, ShowNoDataMessage) = (false, false);

        private void ShowNoDataState(string message)
        {
            ResetDisplay();
            (NoDataMessage, ShowNoDataMessage) = (message, true);
        }

        private string CreateExamSummary(Exam exam, List<Student> all, List<Student> completed)
        {
            var gradeDistribution = GradeCalculationService.GetGradeDistribution(completed);
            var distributionText = string.Join("\n", gradeDistribution.Where(kvp => kvp.Value > 0).Select(kvp => $"  {kvp.Key}: {kvp.Value} studerende"));
            var calculatedAverage = GradeCalculationService.CalculateAverageGrade(completed);
            
            return $"""
                {exam.CourseName}
                Eksamenstermin: {exam.ExamTermin}
                Dato: {exam.Date}
                Tid: {exam.StartTime}
                
                Status: {completed.Count}/{all.Count} gennemført
                Gennemsnitskarakter: {calculatedAverage}
                
                Karakterfordeling:
                {distributionText}
                """;
        }

        private async Task ExecuteAsync(Func<Task> operation)
        {
            if (IsBusy) return;
            try { IsBusy = true; await operation(); }
            catch { ShowNoDataState("Der opstod en fejl ved indlæsning af data."); }
            finally { IsBusy = false; }
        }
    }
} 