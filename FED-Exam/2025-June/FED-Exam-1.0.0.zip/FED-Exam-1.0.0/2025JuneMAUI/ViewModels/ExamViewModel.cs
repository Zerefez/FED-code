using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using _2025JuneMAUI.Models;
using _2025JuneMAUI.Services;

namespace _2025JuneMAUI.ViewModels
{
    public partial class ExamViewModel : BaseViewModel
    {
        private readonly IExamService _examService;

        [ObservableProperty] private Exam selectedExam = new();
        [ObservableProperty] private string examTermin = string.Empty;
        [ObservableProperty] private string courseName = string.Empty;
        [ObservableProperty] private DateTime date = DateTime.Today;
        [ObservableProperty] private int numberOfQuestions = 10;
        [ObservableProperty] private int examDurationMinutes = 15;
        [ObservableProperty] private string startTime = "09:00";

        public ExamViewModel(IExamService examService)
        {
            _examService = examService;
            Title = "Opret Eksamen";
            Exams = new ObservableCollection<Exam>();
            _ = LoadExams();
        }

        public ObservableCollection<Exam> Exams { get; }

        partial void OnSelectedExamChanged(Exam value) => LoadExamToForm(value);

        [RelayCommand] 
        private async Task LoadExams() => await ExecuteAsync(async () =>
            UpdateCollectionFromList(Exams, await _examService.GetAllExamsAsync()));

        [RelayCommand] 
        private async Task AddExam() => await ExecuteAsync(async () =>
        {
            var exam = await _examService.CreateExamAsync(ExamTermin, CourseName, Date.ToString("yyyy-MM-dd"), NumberOfQuestions, ExamDurationMinutes, StartTime);
            Exams.Insert(0, exam);
            ClearForm();
        });

        [RelayCommand(CanExecute = nameof(CanUpdateExam))]
        private async Task UpdateExam() => await ExecuteAsync(async () =>
        {
            var updatedExam = await _examService.UpdateExamAsync(SelectedExam.Id, ExamTermin, CourseName, Date.ToString("yyyy-MM-dd"), NumberOfQuestions, ExamDurationMinutes, StartTime);
            var index = Exams.ToList().FindIndex(e => e.Id == updatedExam.Id);
            if (index >= 0) Exams[index] = updatedExam;
        });

        [RelayCommand] 
        private async Task DeleteExam(Exam? examToDelete = null) => await ExecuteAsync(async () =>
        {
            var exam = examToDelete ?? SelectedExam;
            if (exam?.Id > 0 && await _examService.DeleteExamAsync(exam.Id))
            {
                Exams.Remove(exam);
                if (exam == SelectedExam) ClearForm();
            }
        });

        [RelayCommand] 
        private void ClearForm() => 
            (SelectedExam, ExamTermin, CourseName, Date, NumberOfQuestions, ExamDurationMinutes, StartTime) = 
            (new Exam(), string.Empty, string.Empty, DateTime.Today, 10, 15, "09:00");

        private bool CanUpdateExam() => SelectedExam?.Id > 0;

        private void LoadExamToForm(Exam exam) => 
            (ExamTermin, CourseName, Date, NumberOfQuestions, ExamDurationMinutes, StartTime) = 
            (exam.ExamTermin, exam.CourseName, DateTime.TryParse(exam.Date, out var parsedDate) ? parsedDate : DateTime.Today, exam.NumberOfQuestions, exam.ExamDurationMinutes, exam.StartTime);
    }
} 