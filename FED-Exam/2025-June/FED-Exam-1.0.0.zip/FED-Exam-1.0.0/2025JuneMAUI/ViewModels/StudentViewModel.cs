using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using _2025JuneMAUI.Models;
using _2025JuneMAUI.Services;

namespace _2025JuneMAUI.ViewModels
{
    public partial class StudentViewModel : BaseViewModel
    {
        private readonly IExamService _examService;
        private readonly IStudentService _studentService;
        private readonly IDialogService _dialogService;

        [ObservableProperty] private Student selectedStudent = new();
        [ObservableProperty] private Exam selectedExam = new();
        [ObservableProperty] private string studentNo = string.Empty;
        [ObservableProperty] private string firstName = string.Empty;
        [ObservableProperty] private string lastName = string.Empty;
        [ObservableProperty] private int examinationOrder = 1;

        public StudentViewModel(IExamService examService, IStudentService studentService, IDialogService dialogService)
        {
            (_examService, _studentService, _dialogService) = (examService, studentService, dialogService);
            Title = "Administrer Studerende";
            (Students, Exams) = (new(), new());
            _ = LoadExams();
        }

        public ObservableCollection<Student> Students { get; }
        public ObservableCollection<Exam> Exams { get; }

        partial void OnSelectedStudentChanged(Student value) => LoadStudentToForm(value);

        partial void OnSelectedExamChanged(Exam value)
        {
            if (value?.Id > 0) _ = LoadStudents();
        }

        [RelayCommand] 
        private async Task LoadExams() => await ExecuteAsync(async () =>
            UpdateCollectionFromList(Exams, await _examService.GetAllExamsAsync()), _dialogService);

        [RelayCommand] 
        private async Task LoadStudents() => await ExecuteAsync(async () =>
        {
            if (SelectedExam?.Id > 0) 
                UpdateCollectionFromList(Students, await _studentService.GetStudentsForExamAsync(SelectedExam.Id));
            else
                Students.Clear();
        }, _dialogService);

        [RelayCommand] 
        private async Task AddStudent() => await ExecuteAsync(async () =>
        {
            if (!await _studentService.ValidateStudentDataAsync(SelectedExam?.Id ?? 0, StudentNo, FirstName, LastName)) return;
            var order = await _studentService.GetNextOrderAsync(SelectedExam.Id);
            var student = await _studentService.CreateStudentAsync(SelectedExam.Id, StudentNo, FirstName, LastName, order);
            Students.Add(student);
            ClearForm();
        }, _dialogService);

        [RelayCommand(CanExecute = nameof(CanUpdateStudent))]
        private async Task UpdateStudent() => await ExecuteAsync(async () =>
        {
            if (!await _studentService.ValidateStudentDataAsync(SelectedExam?.Id ?? 0, StudentNo, FirstName, LastName)) return;
            var updatedStudent = await _studentService.UpdateStudentAsync(SelectedStudent.Id, StudentNo, FirstName, LastName, ExaminationOrder);
            var index = Students.ToList().FindIndex(s => s.Id == updatedStudent.Id);
            if (index >= 0) Students[index] = updatedStudent;
            await UpdateExaminationOrder();
        }, _dialogService);

        [RelayCommand] 
        private async Task DeleteStudent(Student? studentToDelete = null) => await ExecuteAsync(async () =>
        {
            var student = studentToDelete ?? SelectedStudent;
            if (student?.Id > 0 && await _studentService.DeleteStudentAsync(student.Id))
            {
                Students.Remove(student);
                if (student == SelectedStudent) ClearForm();
                await UpdateExaminationOrder();
            }
        }, _dialogService);

        [RelayCommand] 
        private async Task MoveStudentUp(Student student) => await ExecuteAsync(async () =>
        {
            var currentIndex = Students.ToList().FindIndex(s => s.Id == student.Id);
            if (currentIndex > 0)
            {
                var previousStudent = Students[currentIndex - 1];
                await _studentService.SwapStudentOrdersAsync(student.Id, previousStudent.Id);
                await LoadStudents();
            }
        }, _dialogService);

        [RelayCommand] 
        private async Task MoveStudentDown(Student student) => await ExecuteAsync(async () =>
        {
            var currentIndex = Students.ToList().FindIndex(s => s.Id == student.Id);
            if (currentIndex < Students.Count - 1)
            {
                var nextStudent = Students[currentIndex + 1];
                await _studentService.SwapStudentOrdersAsync(student.Id, nextStudent.Id);
                await LoadStudents();
            }
        }, _dialogService);

        [RelayCommand] 
        private void ClearForm() => 
            (SelectedStudent, StudentNo, FirstName, LastName, ExaminationOrder) = 
            (new Student(), string.Empty, string.Empty, string.Empty, 1);

        public async Task<string> GetExamStatsAsync() => SelectedExam?.Id > 0 ? await _studentService.GetExamStatsAsync(SelectedExam.Id) : "Ingen eksamen valgt";

        private bool CanUpdateStudent() => SelectedStudent?.Id > 0;

        private async Task UpdateExaminationOrder()
        {
            if (SelectedExam?.Id > 0) ExaminationOrder = await _studentService.GetNextOrderAsync(SelectedExam.Id);
        }

        private void LoadStudentToForm(Student student) => 
            (StudentNo, FirstName, LastName, ExaminationOrder) = 
            (student.StudentNo, student.FirstName, student.LastName, student.ExaminationOrder);
    }
} 