using CommunityToolkit.Mvvm.ComponentModel;
using _2025JuneMAUI.Services;

namespace _2025JuneMAUI.ViewModels
{
    public partial class BaseViewModel : ObservableObject
    {
        [ObservableProperty]
        private bool isBusy;

        [ObservableProperty]
        private string title = string.Empty;

        protected virtual async Task ExecuteAsync(Func<Task> operation, IDialogService? dialogService = null, bool showErrors = true)
        {
            if (IsBusy) return;
            try 
            { 
                IsBusy = true; 
                await operation(); 
            }
            catch (Exception ex) 
            { 
                if (showErrors && dialogService != null)
                    await dialogService.ShowAlertAsync("Fejl", $"Der opstod en fejl: {ex.Message}");
            }
            finally 
            { 
                IsBusy = false; 
            }
        }

        protected static void UpdateCollectionFromList<T>(System.Collections.ObjectModel.ObservableCollection<T> collection, IEnumerable<T> items)
        {
            collection.Clear();
            foreach (var item in items) 
                collection.Add(item);
        }
    }
} 