using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using _2025JuneMAUI.Models;
using _2025JuneMAUI.Services;
using System.Collections.ObjectModel;

namespace _2025JuneMAUI.ViewModels
{
    public partial class ExamSessionViewModel : BaseViewModel, IDisposable
    {
        private readonly IExamService _examService;
        private readonly IExamSessionService _examSessionService;
        private readonly ITimerService _timerService;
        private readonly IDialogService _dialogService;
        private readonly IDataService _dataService;
        private int _drawnQuestionNumber;

        [ObservableProperty] private Exam? selectedExam;
        [ObservableProperty] private Student? currentStudent;
        [ObservableProperty] private int currentStudentIndex;
        [ObservableProperty] private string examInfo = string.Empty, studentInfo = string.Empty, progressInfo = string.Empty, drawnQuestionDisplay = string.Empty, timerDisplay = "00:00", timerColor = "Black", timerStatus = "Tid tilbage", notes = string.Empty, grade = string.Empty, actualExaminationTime = string.Empty, studentSummaryInfo = string.Empty;
        [ObservableProperty] private bool isExamStarted, showExamSelection = true, showExamInfo, hasDrawnQuestion, isTimerRunning, showDrawQuestionButton = true, showStartExaminationButton, showEndExaminationButton, showDataEntry, showActualTime, showSaveButton, showStudentSummary, showExamCompletionOverview, canEditNotes, canEnterGrade;

        public ExamSessionViewModel(IExamService examService, IExamSessionService examSessionService, ITimerService timerService, IDialogService dialogService, IDataService dataService)
        {
            (_examService, _examSessionService, _timerService, _dialogService, _dataService) = (examService, examSessionService, timerService, dialogService, dataService);
            Title = "Start Eksamen";
            (Exams, Students, AvailableGrades) = (new(), new(), new(_examSessionService.GetAvailableGrades()));
            _timerService.TimerTick += OnTimerTick;
            _ = LoadExams();
        }

        private void OnTimerTick(object? sender, int remainingSeconds) => MainThread.BeginInvokeOnMainThread(() =>
        {
            var totalDurationSeconds = (SelectedExam?.ExamDurationMinutes ?? 15) * 60;
            TimerDisplay = _examSessionService.FormatTime(remainingSeconds);
            TimerColor = _examSessionService.GetTimerColor(remainingSeconds, totalDurationSeconds);
            if (remainingSeconds <= 0 && _timerService.IsCountdownMode && IsTimerRunning) EndExamination();
        });

        public ObservableCollection<Exam> Exams { get; }
        public ObservableCollection<Student> Students { get; }
        public ObservableCollection<string> AvailableGrades { get; }

        partial void OnSelectedExamChanged(Exam? value) => 
            (ExamInfo, ShowExamInfo) = value?.Id > 0 ? ($"{value.CourseName} - {value.Date}", true) : (string.Empty, false);

        partial void OnCurrentStudentChanged(Student? value)
        {
            if (value?.Id > 0)
            {
                (StudentInfo, ProgressInfo, Notes, Grade) = (
                    $"{value.FirstName} {value.LastName} ({value.StudentNo})", 
                    Students?.Count > 0 ? $"Studerende {Math.Max(0, CurrentStudentIndex) + 1} af {Students.Count}" : "Ingen studerende", 
                    value.Notes ?? string.Empty, 
                    value.Grade ?? string.Empty);
                
                if (_examSessionService.IsStudentCompleted(value)) 
                    ShowCompletedStudent(); 
                else 
                    ResetWorkflow();
            }
            else 
            {
                (StudentInfo, ProgressInfo, Notes, Grade) = (string.Empty, string.Empty, string.Empty, string.Empty);
            }
        }

        [RelayCommand]
        private async Task LoadExams() => await ExecuteAsync(async () => 
            UpdateCollectionFromList(Exams, await _examService.GetAllExamsAsync()), showErrors: false);

        [RelayCommand]
        private async Task LoadStudents(int examId) => await ExecuteAsync(async () => 
        {
            if (examId > 0) 
                UpdateCollectionFromList(Students, await _examSessionService.GetStudentsForExamAsync(examId));
            else
                Students.Clear();
        }, showErrors: false);

        [RelayCommand]
        private async Task StartExam() => await ExecuteAsync(async () =>
        {
            if (SelectedExam?.Id <= 0) 
            { 
                await _dialogService.ShowAlertAsync("Fejl", "Vælg eksamen først"); 
                return; 
            }
            
            var examId = SelectedExam.Id;
            await LoadStudents(examId);
            
            var (total, completed, _) = await _examSessionService.GetExamProgressAsync(examId);
            if (completed == total && total > 0) 
            { 
                await ShowExamCompletion(examId, total, completed); 
                return; 
            }
            
            var firstStudent = await _examSessionService.FindFirstUncompletedStudentAsync(examId);
            if (firstStudent == null) 
            { 
                await _dialogService.ShowAlertAsync("Info", "Ingen studerende tilmeldt eksamen!"); 
                return; 
            }
            
            var studentIndex = Students.ToList().FindIndex(s => s.Id == firstStudent.Id);
            if (studentIndex == -1) 
            { 
                await LoadStudents(examId); 
                studentIndex = Students.ToList().FindIndex(s => s.Id == firstStudent.Id); 
            }
            if (studentIndex == -1) 
            { 
                Students.Insert(0, firstStudent); 
                studentIndex = 0; 
            }
            
            (IsExamStarted, ShowExamSelection, ShowExamCompletionOverview, CurrentStudentIndex, CurrentStudent) = 
                (true, false, false, studentIndex, firstStudent);
            
            await _dialogService.ShowAlertAsync("Eksamen startet", 
                $"Næste: {firstStudent.FirstName} {firstStudent.LastName}\nStatus: {completed}/{total} færdige");
        }, _dialogService);

        [RelayCommand]
        private void DrawQuestion()
        {
            if (SelectedExam?.NumberOfQuestions <= 0) return;
            _drawnQuestionNumber = _examSessionService.DrawRandomQuestion(SelectedExam.NumberOfQuestions);
            (DrawnQuestionDisplay, HasDrawnQuestion, ShowDrawQuestionButton, ShowStartExaminationButton) = ($"Spørgsmål {_drawnQuestionNumber}", true, false, true);
        }

        [RelayCommand]
        private void StartExamination()
        {
            if (SelectedExam?.ExamDurationMinutes <= 0) return;
            
            _timerService.SetCountdownDuration(SelectedExam.ExamDurationMinutes);
            TimerDisplay = _examSessionService.FormatTime(SelectedExam.ExamDurationMinutes * 60);
            TimerStatus = "Tid tilbage";
            _timerService.Start();
            
            (IsTimerRunning, ShowStartExaminationButton, ShowEndExaminationButton, ShowDataEntry, CanEditNotes) = 
                (true, false, true, true, true);
            CanEnterGrade = false;
            ShowSaveButton = false;
        }

        [RelayCommand] 
        private void EndExamination() 
        { 
            _timerService.Stop(); 
            
            var elapsedMinutes = _timerService.GetElapsedMinutes();
            var elapsedSeconds = _timerService.ElapsedSeconds;
            TimerDisplay = _examSessionService.FormatTime(elapsedSeconds);
            TimerColor = "#DC2626";
            TimerStatus = "Eksamen afsluttet";
            
            (ActualExaminationTime, ShowEndExaminationButton, ShowActualTime, CanEnterGrade, ShowSaveButton) = 
                ($"Faktisk eksaminationstid: {elapsedMinutes} min ({TimerDisplay})", false, true, true, true); 
            
            CanEditNotes = true;
        }

        [RelayCommand]
        private async Task SaveStudentData() => await ExecuteAsync(async () =>
        {
            if (CurrentStudent?.Id <= 0 || string.IsNullOrEmpty(Grade)) 
            { 
                await _dialogService.ShowAlertAsync("Fejl", "Vælg karakter"); 
                return; 
            }
            
            if (CurrentStudent != null)
                await _examSessionService.SaveStudentExamDataAsync(CurrentStudent, _drawnQuestionNumber, _timerService.GetElapsedMinutes(), Notes, Grade);
            (ShowSaveButton, ShowDataEntry, CanEditNotes, CanEnterGrade, ShowStudentSummary) = (false, false, false, false, true);
            if (CurrentStudent != null)
                StudentSummaryInfo = await _examSessionService.GetStudentSummaryAsync(CurrentStudent);
        }, _dialogService);

        [RelayCommand]
        private async Task NextStudent() => await ExecuteAsync(async () =>
        {
            if (SelectedExam?.Id <= 0) return;
            
            var examId = SelectedExam.Id;
            var nextStudent = await _examSessionService.GetCurrentStudentAsync(examId, CurrentStudentIndex + 1);
            
            if (nextStudent != null && !_examSessionService.IsStudentCompleted(nextStudent)) 
            {
                (CurrentStudent, CurrentStudentIndex) = (nextStudent, CurrentStudentIndex + 1);
            }
            else if (await _examSessionService.HasUncompletedStudentsAsync(examId)) 
            { 
                var uncompleted = await _examSessionService.FindFirstUncompletedStudentAsync(examId); 
                if (uncompleted != null) CurrentStudent = uncompleted; 
            }
            else 
            { 
                var (total, completed, _) = await _examSessionService.GetExamProgressAsync(examId); 
                await ShowExamCompletion(examId, total, completed); 
                (ShowExamCompletionOverview, ShowStudentSummary, IsExamStarted, ShowExamSelection) = (true, false, false, true); 
            }
        }, showErrors: false);

        [RelayCommand]
        private void BackToSelection()
        {
            try { _timerService.Stop(); _timerService.Reset(); } catch { }
            (ShowExamSelection, ShowExamInfo, IsExamStarted, ShowExamCompletionOverview, ShowStudentSummary) = (true, false, false, false, false);
            (SelectedExam, CurrentStudent, CurrentStudentIndex) = (null, null, 0);
            ResetWorkflow();
        }

        private void ResetWorkflow()
        {
            (HasDrawnQuestion, ShowDrawQuestionButton, ShowStartExaminationButton, ShowEndExaminationButton) = (false, true, false, false);
            (ShowDataEntry, ShowActualTime, CanEditNotes, CanEnterGrade, ShowSaveButton, ShowStudentSummary, ShowExamCompletionOverview) = (false, false, false, false, false, false, false);
            (DrawnQuestionDisplay, TimerDisplay, TimerColor, TimerStatus, ActualExaminationTime, StudentSummaryInfo, IsTimerRunning) = (string.Empty, "00:00", "Black", "Tid tilbage", string.Empty, string.Empty, false);
            try { _timerService.Reset(); } catch { }
        }

        private void ShowCompletedStudent()
        {
            ResetWorkflow();
            (StudentSummaryInfo, ShowStudentSummary) = (
                $"✅ EKSAMEN ALLEREDE GENNEMFØRT\n\n{CurrentStudent?.FirstName} {CurrentStudent?.LastName}\nStudienummer: {CurrentStudent?.StudentNo}\nSpørgsmål: {CurrentStudent?.QuestionNo}\nKarakter: {CurrentStudent?.Grade}", 
                true);
        }

        private async Task ShowExamCompletion(int examId, int total, int completed)
        {
            var average = await _dataService.GetExamAverageGradeAsync(examId);
            (StudentSummaryInfo, ShowExamCompletionOverview, IsExamStarted, ShowExamSelection) = (
                $"🎉 EKSAMEN AFSLUTTET\n\nAlle {total} studerende har gennemført eksamen.\n\n📊 Status: {completed}/{total} færdige\n📈 Gennemsnit: {average:F1}", 
                true, false, false);
        }

        public void Dispose() => _timerService.TimerTick -= OnTimerTick;
    }
}