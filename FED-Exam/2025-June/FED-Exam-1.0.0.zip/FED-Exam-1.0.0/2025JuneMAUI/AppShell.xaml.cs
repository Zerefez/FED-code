﻿namespace _2025JuneMAUI;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
