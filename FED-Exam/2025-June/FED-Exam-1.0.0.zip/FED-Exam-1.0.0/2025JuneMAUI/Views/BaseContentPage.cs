using CommunityToolkit.Mvvm.Input;
using _2025JuneMAUI.ViewModels;

namespace _2025JuneMAUI.Views
{
    public abstract class BaseContentPage<TViewModel> : ContentPage where TViewModel : BaseViewModel
    {
        protected readonly TViewModel ViewModel;

        protected BaseContentPage(TViewModel viewModel)
        {
            ViewModel = viewModel;
            BindingContext = viewModel;
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await OnPageAppearing();
        }

        protected virtual async Task OnPageAppearing()
        {
            // Default implementation does nothing, derived classes can override
            await Task.CompletedTask;
        }

        protected async Task ExecuteRefreshCommand(IAsyncRelayCommand? command)
        {
            if (command?.CanExecute(null) == true)
                await command.ExecuteAsync(null);
        }
    }
} 