using _2025JuneMAUI.ViewModels;

namespace _2025JuneMAUI.Views;

public partial class HistoryPage : BaseContentPage<HistoryViewModel>
{
    public HistoryPage(HistoryViewModel viewModel) : base(viewModel)
    {
        InitializeComponent();
    }

    protected override async Task OnPageAppearing()
    {
        await ExecuteRefreshCommand(ViewModel.LoadExamsCommand);
    }
} 