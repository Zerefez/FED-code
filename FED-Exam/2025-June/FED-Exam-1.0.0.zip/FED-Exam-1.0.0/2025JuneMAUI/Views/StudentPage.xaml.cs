using _2025JuneMAUI.ViewModels;

namespace _2025JuneMAUI.Views;

public partial class StudentPage : BaseContentPage<StudentViewModel>
{
    public StudentPage(StudentViewModel viewModel) : base(viewModel)
    {
        InitializeComponent();
    }

    protected override async Task OnPageAppearing()
    {
        await ExecuteRefreshCommand(ViewModel.LoadExamsCommand);
    }
} 