using _2025JuneMAUI.ViewModels;

namespace _2025JuneMAUI.Views;

public partial class ExamPage : BaseContentPage<ExamViewModel>
{
    public ExamPage(ExamViewModel viewModel) : base(viewModel)
    {
        InitializeComponent();
    }

    protected override async Task OnPageAppearing()
    {
        await ExecuteRefreshCommand(ViewModel.LoadExamsCommand);
    }
} 