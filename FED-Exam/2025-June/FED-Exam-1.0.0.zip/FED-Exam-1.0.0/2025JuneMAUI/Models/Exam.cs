using SQLite;

namespace _2025JuneMAUI.Models
{
    [Table("Exams")]
    public class Exam
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public string ExamTermin { get; set; } = string.Empty;
        public string CourseName { get; set; } = string.Empty;
        public string Date { get; set; } = string.Empty; // Using string for simplicity, could be DateTime
        public int NumberOfQuestions { get; set; }
        public int ExamDurationMinutes { get; set; }
        public string StartTime { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
} 