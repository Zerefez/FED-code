using SQLite;

namespace _2025JuneMAUI.Models
{
    [Table("ExamSessions")]
    public class ExamSession
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public int ExamId { get; set; }
        public int CurrentStudentIndex { get; set; } = 0;
        public bool IsActive { get; set; } = true;
        public DateTime StartedAt { get; set; } = DateTime.Now;
        public DateTime? CompletedAt { get; set; }
        public string Status { get; set; } = "Active"; // Active, Paused, Completed
    }
} 