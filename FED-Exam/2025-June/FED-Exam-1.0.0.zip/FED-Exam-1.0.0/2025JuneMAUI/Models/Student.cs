using SQLite;

namespace _2025JuneMAUI.Models
{
    [Table("Students")]
    public class Student
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public int ExamId { get; set; } // Foreign key to Exam
        public string StudentNo { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public int QuestionNo { get; set; }
        public int ExamDurationMinutes { get; set; }
        public string Notes { get; set; } = string.Empty;
        public string Grade { get; set; } = string.Empty;
        public int ExaminationOrder { get; set; } // Order in which students should be examined
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
} 