﻿namespace _2025JuneMAUI;

public partial class MainPage : ContentPage
{
	public MainPage()
	{
		InitializeComponent();
	}

	private async void OnExamPageClicked(object? sender, EventArgs e)
	{
		await Shell.Current.GoToAsync("//ExamPage");
	}

	private async void OnStudentPageClicked(object? sender, EventArgs e)
	{
		await Shell.Current.GoToAsync("//StudentPage");
	}

	private async void OnStartExamPageClicked(object? sender, EventArgs e)
	{
		await Shell.Current.GoToAsync("//ExamSessionPage");
	}

	private async void OnHistoryPageClicked(object? sender, EventArgs e)
	{
		await Shell.Current.GoToAsync("//HistoryPage");
	}
}
