using _2025JuneMAUI.Models;
using SQLite;

namespace _2025JuneMAUI.Data
{
    public class Database
    {
        private readonly SQLiteAsyncConnection? _connection;
        private readonly Task _initializationTask;
        private bool _isInitialized = false;
        
        public Database()
        {
            try
            {
                var dataDir = FileSystem.AppDataDirectory;
                if (!Directory.Exists(dataDir))
                {
                    Directory.CreateDirectory(dataDir);
                }
                var databasePath = Path.Combine(dataDir, "ExamManagement.db");
                var dbOptions = new SQLiteConnectionString(databasePath, true);
                _connection = new SQLiteAsyncConnection(dbOptions);
                _initializationTask = InitializeAsync();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Database initialization error: {ex.Message}");
                _initializationTask = Task.FromException(ex);
                throw;
            }
        }
        
        private async Task InitializeAsync()
        {
            try
            {
                if (_connection == null)
                    throw new InvalidOperationException("Database connection is null");
                    
                await _connection.CreateTableAsync<Exam>();
                await _connection.CreateTableAsync<Student>();
                await _connection.CreateTableAsync<ExamSession>();
                _isInitialized = true;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Database table creation error: {ex.Message}");
                throw;
            }
        }

        private async Task<T> ExecuteAsync<T>(Func<SQLiteAsyncConnection, Task<T>> operation, T defaultValue = default!)
        {
            await EnsureInitializedAsync();
            if (_connection == null) return defaultValue;
            return await operation(_connection);
        }

        private async Task EnsureInitializedAsync()
        {
            try
            {
                await _initializationTask;
                if (!_isInitialized)
                    throw new InvalidOperationException("Database failed to initialize");
                if (_connection == null)
                    throw new InvalidOperationException("Database connection is null");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Database ensure initialized error: {ex.Message}");
                throw;
            }
        }

        // Exam CRUD operations
        public async Task<List<Exam>> GetExamsAsync() => 
            await ExecuteAsync(conn => conn.Table<Exam>().ToListAsync(), new List<Exam>());

        public async Task<Exam?> GetExamAsync(int id) => 
            await ExecuteAsync(conn => conn.Table<Exam>().Where(e => e.Id == id).FirstOrDefaultAsync());

        public async Task<int> AddExamAsync(Exam exam) => 
            await ExecuteAsync(conn => conn.InsertAsync(exam));

        public async Task<int> DeleteExamAsync(Exam exam) => 
            await ExecuteAsync(async conn => {
                // First delete all students for this exam
                var students = await GetStudentsByExamIdAsync(exam.Id);
                foreach (var student in students)
                {
                    await conn.DeleteAsync(student);
                }
                return await conn.DeleteAsync(exam);
            });

        public async Task<int> UpdateExamAsync(Exam exam) => 
            await ExecuteAsync(conn => conn.UpdateAsync(exam));

        // Student CRUD operations
        public async Task<List<Student>> GetStudentsAsync() => 
            await ExecuteAsync(conn => conn.Table<Student>().ToListAsync(), new List<Student>());

        public async Task<List<Student>> GetStudentsByExamIdAsync(int examId) => 
            await ExecuteAsync(conn => conn.Table<Student>()
                .Where(s => s.ExamId == examId)
                .OrderBy(s => s.ExaminationOrder)
                .ThenBy(s => s.CreatedAt)
                .ToListAsync(), new List<Student>());

        public async Task<Student?> GetStudentAsync(int id) => 
            await ExecuteAsync(conn => conn.Table<Student>().Where(s => s.Id == id).FirstOrDefaultAsync());

        public async Task<int> AddStudentAsync(Student student) => 
            await ExecuteAsync(conn => conn.InsertAsync(student));

        public async Task<int> DeleteStudentAsync(Student student) => 
            await ExecuteAsync(conn => conn.DeleteAsync(student));

        public async Task<int> UpdateStudentAsync(Student student) => 
            await ExecuteAsync(conn => conn.UpdateAsync(student));

        // Additional utility methods
        public async Task<double> GetExamAverageGradeAsync(int examId)
        {
            var students = await GetStudentsByExamIdAsync(examId);
            var gradesWithValues = students
                .Where(s => !string.IsNullOrEmpty(s.Grade) && double.TryParse(s.Grade, out _))
                .Select(s => double.Parse(s.Grade))
                .ToList();

            return gradesWithValues.Any() ? gradesWithValues.Average() : 0.0;
        }

        public async Task<int> GetTotalStudentsForExamAsync(int examId) => 
            await ExecuteAsync(conn => conn.Table<Student>().Where(s => s.ExamId == examId).CountAsync());

        public async Task<int> GetCompletedStudentsForExamAsync(int examId) => 
            await ExecuteAsync(conn => conn.Table<Student>()
                .Where(s => s.ExamId == examId && !string.IsNullOrEmpty(s.Grade))
                .CountAsync());

        public async Task<int> GetNextExaminationOrderAsync(int examId)
        {
            var students = await GetStudentsByExamIdAsync(examId);
            return students.Any() ? students.Max(s => s.ExaminationOrder) + 1 : 1;
        }
    }
}